package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.member.MemberSessionUtils;
import controller.rent.RentListSessionUtils;
import controller.team.TeamSmallListSessionUtils;
import controller.team.TeamSmallSessionUtils;
import controller.teamLarge.TeamLargeListSessionUtils;

public class ForwardController implements Controller {
    private String forwardUrl;

    public ForwardController(String forwardUrl) {
        if (forwardUrl == null) {
            throw new NullPointerException("forwardUrl is null. �̵��� URL�� �Է��ϼ���.");
        }
        this.forwardUrl = forwardUrl;
    }

    @Override
    public String execute(HttpServletRequest req, HttpServletResponse resp) throws Exception {
       req.setAttribute("curUserId", 
            MemberSessionUtils.getMemberFromSession(req.getSession()));   
       req.setAttribute("Teamname", 
                TeamSmallSessionUtils.getTeamSmallFromSession1(req.getSession())); 
       req.setAttribute("teamname", 
                TeamSmallListSessionUtils.getTeamSmallListFromSession(req.getSession())); 
       req.setAttribute("rentname", 
             RentListSessionUtils.getRentListLocFromSession(req.getSession())); 
       req.setAttribute("rentname", 
             RentListSessionUtils.getRentListRoomFromSession(req.getSession())); 
       req.setAttribute("teamname", 
             TeamLargeListSessionUtils.getTeamLargeListFromSession(req.getSession())); 

        return forwardUrl;
    }
}