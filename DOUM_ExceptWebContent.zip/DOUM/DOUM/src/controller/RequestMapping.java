package controller;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.member.*;
import controller.mentor.*;
import controller.team.*;
import controller.teamLarge.*;
import controller.rent.*;
import controller.report.*;
import controller.review.*;

public class RequestMapping {
    private static final Logger logger = LoggerFactory.getLogger(DispatcherServlet.class);
 
    private Map<String, Controller> mappings = new HashMap<String, Controller>();

    public void initMapping() {
    	
        mappings.put("/", new ForwardController("index.jsp"));
        mappings.put("/member/login", new LoginController());
        mappings.put("/member/login/form", new ForwardController("/member/loginForm.jsp"));
        mappings.put("/member/logout", new LogoutController());
        mappings.put("/member/register", new RegisterMemberController());
        mappings.put("/member/register/form", new ForwardController("/member/memberJoin.jsp"));

        
        mappings.put("/main/mainpage", new MainPageController());        
        mappings.put("/mypage/mypage", new MyPageController());


        mappings.put("/mentor/mentorList", new ListMentorController());
        mappings.put("/mentor/mentorJoin", new JoinMentorController());
        mappings.put("/mentor/mentorJoin/form", new ForwardController("/mentor/mentorJoin.jsp"));
        mappings.put("/mentor/mentorDetail", new DetailMentorController());    
        mappings.put("/mentor/mentorListView/json", new ViewMentorListJsonController());
        
        mappings.put("/team/myTeamDetail", new myPageTeamController());
        mappings.put("/team/teamSmalljoin", new JoinTeamSmallFormController());
        mappings.put("/team/teamSmalljoin/form", new ForwardController("/team/teamSmallJoin.jsp"));
        mappings.put("/team/teamSmallList", new ListTeamSmallController());
        mappings.put("/team/teamSmallDetail", new DetailTeamSmallController());
        mappings.put("/team/teamSmallWaiting", new ListWaitingController());
        mappings.put("/team/teamSmallWaitinging", new ForwardController("/team/WaitingPage.jsp"));
        mappings.put("/team/teamSmalljoinMentee/form", new ForwardController("/team/teamSmallJoinMentee.jsp"));
        
        mappings.put("/team/teamLeave", new LeaveTeamController());
        mappings.put("/team/teamDelete", new DeleteTeamSmallController());
        
        mappings.put("/team/teamSmallRequest", new RequestTeamSmallController());
        mappings.put("/team/teamSmallWaiting/forming", new AssentTeamSmallMentorController());
        mappings.put("/team/teamSmallDetailRequest",  new DetailRequestTeamSmallController());
        mappings.put("/team/teamSmallView/json", new ViewTeamSmallJsonController());
        
        mappings.put("/teamLarge/teamLargeList", new ListTeamLargeController());
        mappings.put("/teamLarge/teamLargeDetail", new DetailTeamLargeController());
        mappings.put("/teamLarge/teamLargeAttend/form", new ForwardController("/teamLarge/teamLargeAttend.jsp"));
        mappings.put("/teamLarge/teamLargeAttend", new AttendTeamLargeController());
        mappings.put("/teamLarge/teamLargeJoin", new JoinTeamLargeController());
        mappings.put("/teamLarge/teamLargeJoin/form", new ForwardController("/teamLarge/teamLargeJoin.jsp"));
        mappings.put("/teamLarge/teamLargeView/json", new ViewTeamLargeJsonController());
        mappings.put("/teamLarge/teamLargeDetailAttend", new DetailAttendTeamLargeController());
        
        mappings.put("/report/reportList", new ListReportController());
        mappings.put("/report/reportJoin/form", new ForwardController("/report/reportJoin.jsp"));
        mappings.put("/report/reportJoin", new JoinReportController());
        
        mappings.put("/review/reviewList", new ListReviewController());
        mappings.put("/review/reviewJoin", new JoinReviewController());
        mappings.put("/review/reviewJoin/form", new JoinFormReviewController());
        mappings.put("/review/reviewDetail", new DetailReviewController());
          
        mappings.put("/rent/rentPlacePageList", new ListRentController());
        mappings.put("/rent/rentPlacePageDetail", new DetailRentPlaceController());
        mappings.put("/rent/rentPlaceRequest", new RequestRentPlaceController());
        mappings.put("/rent/rentPlaceRequest/form", new RequestFormRentPlaceController());
        
        logger.info("Initialized Request Mapping!");
    }

    public Controller findController(String uri) {	
        return mappings.get(uri);
    }
}



