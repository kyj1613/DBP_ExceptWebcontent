package controller.member;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.*;
import model.service.*;


public class MainPageController implements Controller {
   private static final Logger log = LoggerFactory.getLogger(ListStarFieldRecommendController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)   throws Exception {
      
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";      
        }
    

       request.setAttribute("curUserId", 
            MemberSessionUtils.getMemberFromSession(request.getSession()));      
       String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
      
       MemberManager manager = MemberManager.getInstance();
       Member member = manager.findMember(curUserId); 
       

       List<Integer> fieldList = new ArrayList<>();
       fieldList = member.getField();
      
       List<String> fieldNameList = new ArrayList<>();
        
        FieldManager manager3 = FieldManager.getInstance();
      
        for(int i = 0; i < 3; i++) {
           String field = manager3.findFieldByNum(fieldList.get(i));
           fieldNameList.add(field);
        }

        List<Mentor> mentorRecommendList1 = new ArrayList<Mentor>();
        mentorRecommendList1 = manager.recommendMentors(fieldList.get(0));
        
        List<Mentor> mentorRecommendList2 = new ArrayList<Mentor>();
        mentorRecommendList2 = manager.recommendMentors(fieldList.get(1));
        
        List<Mentor> mentorRecommendList3 = new ArrayList<Mentor>();
        mentorRecommendList3 = manager.recommendMentors(fieldList.get(2));
        
        MentorManager manager2 = MentorManager.getInstance();
        List<Mentor> mentorList = manager2.findMentorList();
        
        
        request.setAttribute("isMentor", "false");
        for(int j = 0; j < mentorList.size(); j++) {
            if(mentorList.get(j).getMember().getNum() == member.getNum()) {
               request.setAttribute("isMentor", "true");
               break;
             }
            }
        
        
        
        request.setAttribute("isNotMentor", "false");
        for(int j = 0; j < mentorList.size(); j++) {
            if(mentorList.get(j).getMember().getNum() == member.getNum()) {
            	request.setAttribute("isNotMentor", "true");
               break;
             }
           
            }
        
        
        
        
        
        request.setAttribute("fieldNameList", fieldNameList);      
      request.setAttribute("mentorRecommendList1", mentorRecommendList1);            
      request.setAttribute("mentorRecommendList2", mentorRecommendList2);   
      request.setAttribute("mentorRecommendList3", mentorRecommendList3);   

      return "/main/mainPage.jsp";        
    }
}