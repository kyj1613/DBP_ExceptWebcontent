package controller.member;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.service.*;
import model.*;

public class MyPageController implements Controller {
	
	private static final Logger log = LoggerFactory.getLogger(MyPageController.class);
	
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {			

    	if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";		
        }
    	
    	Member member = null;
    	MemberManager manager = MemberManager.getInstance();
    	FieldManager manager2 = FieldManager.getInstance();
    	TeamSmallManager manager3 = TeamSmallManager.getInstance();
    	MentorManager manager4 = MentorManager.getInstance();
    	WaitingManager manager6 = WaitingManager.getInstance();
    	TeamLargeManager manager7 = TeamLargeManager.getInstance();
  
		request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		
		
		String curUserId = request.getParameter("curUserId");

		member = manager.findMember(curUserId);	// ����� ���� �˻�
		
		Mentor mentor = manager4.findMentorById1(member.getId());
		
		List<Integer> fieldList = new ArrayList<>();
    	fieldList = member.getField();
		
		List<String> fieldNameList = new ArrayList<>();
		
		//fieldnum�� �ش��ϴ� fieldname���� ã��
		for(int i = 0; i < 3; i++) {
			String field = manager2.findFieldByNum(fieldList.get(i));
			fieldNameList.add(field);
		}
		
		List<TeamSmall> teamSmallNameList = manager3.findTnameByMnum(member.getNum());
		List<TeamSmall> teamSmallNameMentorList = manager3.findTnameMentorByMnum(member.getNum());
		List<Waiting> waitingList = manager6.findWaitingMnumList(member.getNum());
  	    List<TeamLarge> teamLargeList = manager7.findTnameByMnum(member.getNum());
  	   
  	   if(mentor != null) {
  		   List<TeamLarge> teamLargeMentorList = manager7.findTnameMentorByMnum(mentor.getNum());
  		   request.setAttribute("teamLargeMentorList", teamLargeMentorList); 
  	   }
  	   
  	   
  	   
  	   
  	   
  	   request.setAttribute("waitingList", waitingList);
  	   request.setAttribute("teamLargeList", teamLargeList);
  	   request.setAttribute("teamSmallNameMentorList", teamSmallNameMentorList);		
  	   request.setAttribute("teamSmallNameList", teamSmallNameList);		
  	   request.setAttribute("fieldNameList", fieldNameList);
  	   request.setAttribute("member", member);
  	   request.setAttribute("mentor", mentor);	
  	   
  	   return "/myPage/myPage.jsp";				
    }
}
