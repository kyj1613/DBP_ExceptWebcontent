package controller.member;

import java.util.List;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import model.Member;
import model.service.ExistingMemberException;
import model.service.MemberManager;
import java.util.ArrayList;

public class RegisterMemberController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(RegisterMemberController.class);
    

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
      List<Integer> field = new ArrayList<Integer>();

        String[] param = request.getParameterValues("field1");
        for(int i=0; i < param.length; i++) {
           field.add(Integer.parseInt(request.getParameter("field1")));
        }
        String[] param2 = request.getParameterValues("field2");
        for(int i=0; i < param2.length; i++) {
           field.add(Integer.parseInt(request.getParameter("field2")));
        }
        String[] param3 = request.getParameterValues("field3");
        for(int i=0; i < param3.length; i++) {
           field.add(Integer.parseInt(request.getParameter("field3")));
        }
    

       Member member = new Member(   
            request.getParameter("id"), 
            request.getParameter("pwd"), 
            request.getParameter("name"), 
            request.getParameter("sex"), 
            request.getParameter("nickname"), 
            request.getParameter("tel"), 
            request.getParameter("birth"), 
            request.getParameter("email"),
            field
            );
      
        log.debug("Create Member : {}", member);

      try {
         MemberManager manager = MemberManager.getInstance();
         manager.create(member);
         return "redirect:/member/login/form";      
           
      } catch (ExistingMemberException e) {     
         request.setAttribute("registerFailed", true);
         request.setAttribute("exception", e);
         request.setAttribute("member", member);
         return "/member/memberJoin.jsp";
      }
    }
}