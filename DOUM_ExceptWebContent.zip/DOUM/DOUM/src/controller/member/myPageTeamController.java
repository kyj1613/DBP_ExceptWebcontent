package controller.member;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import controller.team.AssentTeamSmallMentorController;
import controller.team.TeamSmallListSessionUtils;
import model.service.TeamSmallManager;
import model.service.WaitingManager;
import model.service.MemberManager;
import model.service.MenteeManager;
import model.service.MentorManager;
import model.Member;
import model.Mentee;
import model.Mentor;
import model.TeamSmall;
import model.Waiting;

public class myPageTeamController implements Controller {
	
	private static final Logger log = LoggerFactory.getLogger(myPageTeamController.class);
	
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";     
       }

       TeamSmall teamSmall = null;
        String Teamname = request.getParameter("Teamname");
        
        request.setAttribute("curUserId", 
                MemberSessionUtils.getMemberFromSession(request.getSession()));      
        String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());  
        HttpSession session = request.getSession();///
        session.setAttribute(TeamSmallListSessionUtils.TEAMSMALLList_SESSION_KEY, Teamname); 
       
        request.setAttribute("Teamname", 
        		   TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession()));      
           
        MemberManager manager = MemberManager.getInstance();
        Member member = manager.findMember(curUserId);
        
        
         MentorManager manager2 = MentorManager.getInstance();
         MenteeManager manager3 = MenteeManager.getInstance();
         List<Mentee> MenteeList = null;
       
         
         TeamSmall ts = null;
         TeamSmallManager tsmanager = TeamSmallManager.getInstance();
         String fieldname = null;
        
         ts = tsmanager.findTeamSmallByNAME(Teamname);
  	      
         int tnum = ts.getNum();
  	     
         WaitingManager manager6 = WaitingManager.getInstance();
  	     List<Waiting> waitingList = manager6.findWaitingMnumList(member.getNum());
  	      
  	     request.setAttribute("waitingList", waitingList);
         
  	    TeamSmall teamSmallA = tsmanager.findTeamSmall(tnum);

  	  fieldname = tsmanager.findTeamSmallFieldByNAME(Teamname);
         
       try {
          teamSmall = tsmanager.findTeamSmallByNAME(Teamname); 
          
          int mentorNum = teamSmall.getMentorNum();
          Mentor mentor = manager2.findMentor(mentorNum);
          
          request.setAttribute("mentor", mentor);

  
          int teamNum = teamSmall.getNum();
          MenteeList = manager3.findMenteeList(teamNum);   
       } catch (Exception e) {            
            return "redirect:/team/teamSmallList";
       }    
       
       request.setAttribute("ts", ts);
       request.setAttribute("fieldname", fieldname);
       request.setAttribute("teamSmallA", teamSmallA);     
       request.setAttribute("teamSmall", teamSmall);     
       request.setAttribute("MenteeList", MenteeList);   
       
       return "/team/myTeamDetail.jsp";                   
    }
}