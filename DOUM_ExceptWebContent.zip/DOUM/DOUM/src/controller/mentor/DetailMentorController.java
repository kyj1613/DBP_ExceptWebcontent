package controller.mentor;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.service.*;

import model.Mentor;

public class DetailMentorController implements Controller {
	private static final Logger log = LoggerFactory.getLogger(DetailMentorController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         
       
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";      
        }
       request.setAttribute("curUserId", 
               MemberSessionUtils.getMemberFromSession(request.getSession()));      
       
       Mentor mentor = null;
       MentorManager manager = MentorManager.getInstance();
     
      String mid = request.getParameter("mid");
      mentor = manager.findMentorById1(mid);
      FieldManager manager2 = FieldManager.getInstance();
      String fname = manager2.findFieldByNum(mentor.getField1());
      request.setAttribute("fname", fname);
      
      try {
    	  request.setAttribute("mentor", mentor);     
      } catch (Exception e) {            
           return "redirect:/mentor/mentorList";
      }   
      
      
      return "/mentor/mentorDetail.jsp";          
    }
}