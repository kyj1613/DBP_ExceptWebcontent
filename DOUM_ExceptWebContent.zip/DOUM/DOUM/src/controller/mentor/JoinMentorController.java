package controller.mentor;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.*;

import model.*;

import model.service.*;


public class JoinMentorController implements Controller {
  
	private static final Logger log = LoggerFactory.getLogger(JoinMentorController.class);
   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
	   if (!MemberSessionUtils.isLogined(request.getSession())) {
           return "redirect:/member/login/form";      
       }
	   
	   request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		
      String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
      	
      
      
      try{
         MemberManager manager = MemberManager.getInstance();
         Member member = manager.findMember(curUserId);  
         request.setAttribute("member", member);                  
         
         MentorManager manager2 = MentorManager.getInstance();
         Mentor mentor  = new Mentor(request.getParameter("profile"),        
                  Integer.parseInt(request.getParameter("checkfield"))
               );
         
         
          mentor.setMember(member);
         manager2.create(mentor);
         
         
         return "redirect:/mentor/mentorList";
         
      } catch(Exception e) {
         request.setAttribute("updateFailed", true);
         request.setAttribute("exception", new IllegalStateException("다른 사용자의 정보를 수정할 수 없습니다."));            
         return "/mentor/mentorJoin.jsp";    
      }
     
    }
}