package controller.mentor;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.Mentor;
import model.TeamSmall;
import model.service.MentorManager;
import model.service.TeamSmallManager;

public class ListMentorController implements Controller {
    @Override
   public String execute(HttpServletRequest request, HttpServletResponse response)   throws Exception {
      // �α��� ���� Ȯ��
       if (!MemberSessionUtils.isLogined(request.getSession())) {
          return "redirect:/member/login/form";      // login form ��û���� redirect
       }
          
       MentorManager manager = MentorManager.getInstance();
         
      List<Mentor> mentorList = manager.findMentorList();
      
      request.setAttribute("mentorList", mentorList);            
      request.setAttribute("curUserId", 
            MemberSessionUtils.getMemberFromSession(request.getSession()));      

      // ����� ����Ʈ ȭ������ �̵�(forwarding)
      return "/mentor/mentorList.jsp";        
    }
}