
package controller.mentor;

import javax.servlet.http.HttpSession;

public class MentorSessionUtils {
    public static final String USER_SESSION_KEY = "1";

    public static int getMentorFromSession(HttpSession session) {
        int mentorNum = (int)session.getAttribute(USER_SESSION_KEY);
        return mentorNum;
    }
    

    public static boolean isLogined(HttpSession session) {
        if (Integer.toString(getMentorFromSession(session)) != null) {
            return true;
        }
        return false;
    }

}
