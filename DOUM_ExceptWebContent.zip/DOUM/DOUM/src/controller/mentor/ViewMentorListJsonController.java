package controller.mentor;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import controller.Controller;
import controller.member.MemberSessionUtils;
import controller.team.ViewTeamSmallJsonController;
import model.Mentor;
import model.TeamSmall;
import model.service.FieldManager;
import model.service.MenteeManager;
import model.service.MentorManager;
import model.service.TeamSmallManager;

public class ViewMentorListJsonController implements Controller {
	
	private static final Logger logger = LoggerFactory.getLogger(ViewTeamSmallJsonController.class);
	@Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         
       
		List<Mentor> mentorList = null;
		MentorManager manager = MentorManager.getInstance();
		String checkfield = request.getParameter("checkfield"); 
            
		int check_field = Integer.parseInt(checkfield);
      
		FieldManager manager2 = FieldManager.getInstance();
		String searchFieldName = manager2.findFieldByNum(check_field);
      
		mentorList = manager.findByFieldMentorList(check_field);  
      
		logger.debug("checkfield : {}", checkfield);
        
		// Jackson�� �̿��Ͽ� ��� ��ü���� JSON �ؽ�Ʈ�� ��ȯ
		ObjectMapper mapper = new ObjectMapper();   
		String jsonString = mapper.writeValueAsString(mentorList);
		logger.debug("mentorList in JSON : {}", jsonString);

		// JSON �ؽ�Ʈ�� �����ϴ� response message ����
		response.setContentType("application/json;charset=utf-8");   
		PrintWriter out = response.getWriter();
		out.println(jsonString);          
       
		return null;   // uri ��� null�� ���� -> DispatcherServlet���� ��û ó�� ���� 
    }
}