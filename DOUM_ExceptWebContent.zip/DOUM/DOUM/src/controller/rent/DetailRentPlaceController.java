package controller.rent;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import controller.team.TeamSmallSessionUtils;
import model.service.*;
import model.Location;
import model.Member;
import model.Mentor;
import model.RentHis;

public class DetailRentPlaceController implements Controller {
	private static final Logger log = LoggerFactory.getLogger(DetailRentPlaceController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         
       
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";      
        }
       request.setAttribute("curUserId", 
               MemberSessionUtils.getMemberFromSession(request.getSession()));      
       
       String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
       
       LocationManager manager = LocationManager.getInstance();
       int locnum = Integer.parseInt(request.getParameter("locnum"));
       
       Location location = manager.findLocationByLocNum(locnum);
       
       String locnum1 = Integer.toString(location.getLocnum());
       
       HttpSession session = request.getSession();
       session.setAttribute(RentListSessionUtils.RentListLocnum_SESSION_KEY, locnum1);
       
       RentHisManager manager2 = RentHisManager.getInstance();
       
       List<RentHis> rentHisList = manager2.findRentHisLocnumRoomnumList(locnum, 1);
       List<RentHis> rentHisList2 = manager2.findRentHisLocnumRoomnumList(locnum, 2);
       List<RentHis> rentHisList3 = manager2.findRentHisLocnumRoomnumList(locnum, 3);
       request.setAttribute("rentHisList", rentHisList);
       request.setAttribute("rentHisList2", rentHisList2);
       request.setAttribute("rentHisList3", rentHisList3);
            
       
       
       MentorManager manager4 = MentorManager.getInstance();
       List<Mentor> mentorList = manager4.findMentorList();
       
       MemberManager manager3 = MemberManager.getInstance();
       Member member = manager3.findMember(curUserId); 
       
       
       request.setAttribute("isNotMentor", "false");
       for(int j = 0; j < mentorList.size(); j++) {
           if(mentorList.get(j).getMember().getNum() == member.getNum()) {
           	request.setAttribute("isNotMentor", "true");
              break;
            }
          
           }
       
       
       
      try {
    	  request.setAttribute("location", location);     
      } catch (Exception e) {            
           return "redirect:/mentor/mentorList";
      }   
      
      
      return "/rent/RentPlaceDetail.jsp";          
    }
}