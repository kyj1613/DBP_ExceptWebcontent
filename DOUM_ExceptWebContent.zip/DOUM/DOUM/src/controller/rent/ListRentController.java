package controller.rent;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import controller.member.MemberSessionUtils; //�α��εǸ� �� �� �ִ� ȭ��
import model.*;
import model.service.*;

public class ListRentController implements Controller {
   // private static final int countPerPage = 100;   // �� ȭ�鿡 ����� ����� ��

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)   throws Exception {
      // �α��� ���� Ȯ��
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";      // login form ��û���� redirect
        }
    
       request.setAttribute("curUserId", 
                MemberSessionUtils.getMemberFromSession(request.getSession()));      
          String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
           
       LocationManager manager = LocationManager.getInstance();
      
      List<Location> DistinctLocationList = manager.findDistinctLocationList();
   
      
      
      
      request.setAttribute("DistinctLocationList", DistinctLocationList);      
       

      return "/rent/rentPlacePage.jsp";        
    }
}