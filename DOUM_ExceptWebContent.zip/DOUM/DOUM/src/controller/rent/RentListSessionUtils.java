
package controller.rent;

import javax.servlet.http.HttpSession;

public class RentListSessionUtils {
    public static final String RentListLocnum_SESSION_KEY = "locnum";
    public static final String RentListRoomnum_SESSION_KEY = "roomnum";
    
    
    public static String getRentListLocFromSession(HttpSession session) {
        String name = (String)session.getAttribute(RentListLocnum_SESSION_KEY);
        return name;
    }

    public static String getRentListRoomFromSession(HttpSession session) {
        String name = (String)session.getAttribute(RentListRoomnum_SESSION_KEY);
        return name;
    }
    
     
}
