package controller.rent;


import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.*;

import model.*;

import model.service.*;


public class RequestRentPlaceController implements Controller {
  
   private static final Logger log = LoggerFactory.getLogger(RequestRentPlaceController.class);
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
      if (!MemberSessionUtils.isLogined(request.getSession())) {
           return "redirect:/member/login/form";      
       }
      
      request.setAttribute("curUserId", 
            MemberSessionUtils.getMemberFromSession(request.getSession()));      
      String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
         
      try{
         
        MemberManager manager = MemberManager.getInstance();
        Member member = manager.findMember(curUserId);  //�������� ��������...
        
        TeamSmallManager manager2 = TeamSmallManager.getInstance();
        List<TeamSmall> teamSmallNameMentorList = manager2.findTnameMentorByMnum(member.getNum()); //���������� �ڱⰡ ������ ������ ����Ʈ �ҷ�����...
        
       
        request.setAttribute("teamSmallNameMentorList", teamSmallNameMentorList);   
        
        request.setAttribute("locnum1", 
                RentListSessionUtils.getRentListLocFromSession(request.getSession()));   
         String locnum1 = RentListSessionUtils.getRentListLocFromSession(request.getSession());
         
//          request.setAttribute("roomnum1", 
//                RentListSessionUtils.getRentListRoomFromSession(request.getSession()));   
//         String roomnum1 = RentListSessionUtils.getRentListRoomFromSession(request.getSession());   
          
      
          
          int locnum = Integer.parseInt(locnum1);
         int roomnum = Integer.parseInt(request.getParameter("roomnum1"));
         
           
           LocationManager manager3 = LocationManager.getInstance();
          Location location = manager3.findLocationByLocRoom(locnum, roomnum);
          
          
          //������������̸�(�ڵ�����ä����) ��ġ�̸�(�ڵ�����ä����) ��ѹ�(�ڵ�����ä����) ���Ͻð�(�Է�) 
          
          request.setAttribute("location", location);
        
         String teamname = request.getParameter("teamname");
         TeamSmallManager manager4 = TeamSmallManager.getInstance();
         TeamSmall teamSmall = manager4.findTeamSmallByNAME(teamname);
          
          
        RentHisManager manager5 = RentHisManager.getInstance();
       
        RentHis renthis = new RentHis(
              roomnum, 
              locnum, 
              teamSmall.getNum(), 
              request.getParameter("rdate"), 
              request.getParameter("rtime")
              );
        
        manager5.create(renthis);
         
       
        return "redirect:/rent/rentPlacePageList";
         
      } catch(Exception e) {
         request.setAttribute("updateFailed", true);
         request.setAttribute("exception", new IllegalStateException("�ٸ� ������� ������ ������ �� �����ϴ�."));            
         return "/mentor/mentorJoin.jsp";    
      }
      
     
    }
}