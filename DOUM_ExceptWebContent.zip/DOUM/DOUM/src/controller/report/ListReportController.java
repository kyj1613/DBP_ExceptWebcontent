package controller.report;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import controller.member.MemberSessionUtils; //�α��εǸ� �� �� �ִ� ȭ��
import controller.team.TeamSmallListSessionUtils;
import model.*;
import model.service.*;

public class ListReportController implements Controller {
	

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
		// �α��� ���� Ȯ��
    	if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";		// login form ��û���� redirect
        }
    	
    	request.setAttribute("curUserId", 
    			MemberSessionUtils.getMemberFromSession(request.getSession()));		
    	
    	
    	String TeamName = TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession());      
    	
    	
    	
    	
    	
    	
    	TeamSmallManager manager = TeamSmallManager.getInstance();
//		List<TeamLarge> teamLargeList = manager.findTeamLargeList();
		
    	TeamSmall teamSmall = manager.findTeamSmallByNAME(TeamName);
    	//int tnum, String url, String rptUpdate, String url_rcp
		
    	ReportManager manager2 = ReportManager.getInstance();
    	List<Report> reportList = manager2.findReportList(teamSmall.getNum());
		
		request.setAttribute("reportList", reportList);				
		request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		

		// ����� ����Ʈ ȭ������ �̵�(forwarding)
		return "/report/reportList.jsp";        
    }
}
