package controller.review;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.service.*;

import model.Mentor;
import model.Review;

public class DetailReviewController implements Controller {
   private static final Logger log = LoggerFactory.getLogger(DetailReviewController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         
       
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";      
        }
       request.setAttribute("curUserId", 
               MemberSessionUtils.getMemberFromSession(request.getSession()));      
     
       ReviewManager manager2 = ReviewManager.getInstance();
       int reviewnum = Integer.parseInt(request.getParameter("reviewnum"));
       int review1 = manager2.upHit(reviewnum);
       Review review = manager2.findReviewTitleMnum(reviewnum);

       Review reviewStar = manager2.findReviewTitleStarMnum(review.getRevnum());
       
       MentorManager manager3 = MentorManager.getInstance();
       int mentornum = review.getMentornum();
       Mentor mentor = manager3.findMentor(mentornum);
       
       request.setAttribute("reviewStar", reviewStar);     
       request.setAttribute("mentor", mentor);     
           
      try {
         request.setAttribute("review", review);     
      } catch (Exception e) {            
           return "redirect:/review/reviewList";
      }   
      
      return "/review/reviewDetail.jsp";          
    }
}