package controller.review;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.*;

import model.*;

import model.service.*;


public class JoinFormReviewController implements Controller {
  
	private static final Logger log = LoggerFactory.getLogger(JoinFormReviewController.class);
   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
	   if (!MemberSessionUtils.isLogined(request.getSession())) {
           return "redirect:/member/login/form";      
       }
	   
	   request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		
      String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
     
      MemberManager manager = MemberManager.getInstance();
      Member member = manager.findMember(curUserId); 
      
      TeamLargeManager manager3 = TeamLargeManager.getInstance();
      MentorManager manager2 = MentorManager.getInstance();
      TeamSmallManager manager5 = TeamSmallManager.getInstance();
    
      List<TeamSmall> teamSmallTnameList = manager5.findTnameByMnum(member.getNum());
      List<TeamLarge> teamLargeTnameList = manager3.findTnameByMnum(member.getNum());

      List<Mentor> mentorList = new ArrayList<>();
      
      for(int i = 0; i < teamSmallTnameList.size(); i++) {
    	  Mentor mentorname = manager2.findMentor(teamSmallTnameList.get(i).getMentorNum());
    	  mentorList.add(mentorname);
    	 
      }
      List<Mentor> mentorLargeList = new ArrayList<>();
      for(int i = 0; i < teamLargeTnameList.size(); i++) {
    	  Mentor mentorname = manager2.findMentor(teamLargeTnameList.get(i).getMentorNum());
    	  mentorLargeList.add(mentorname);
    	  
      }
      request.setAttribute("teamLargeTnameList", teamLargeTnameList);
      request.setAttribute("teamSmallTnameList", teamSmallTnameList);
      request.setAttribute("mentorList", mentorList);
      request.setAttribute("mentorLargeList", mentorLargeList);
     
    
      try{
    	 
          return "/review/reviewJoin.jsp";	
         
      } catch(Exception e) {
         request.setAttribute("updateFailed", true);
         request.setAttribute("exception", new IllegalStateException("������ �� �����ϴ�."));            
         return "/review/reviewJoin.jsp";    
      }
      
    }
}