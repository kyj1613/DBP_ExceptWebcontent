package controller.review;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.*;

import model.*;

import model.service.*;


public class JoinReviewController implements Controller {
  
	private static final Logger log = LoggerFactory.getLogger(JoinReviewController.class);
   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
	   if (!MemberSessionUtils.isLogined(request.getSession())) {
           return "redirect:/member/login/form";      
       }
	   
	   request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		
      String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
     
      MemberManager manager = MemberManager.getInstance();
      Member member = manager.findMember(curUserId);  
      request.setAttribute("member", member);     
      MentorManager manager2 = MentorManager.getInstance();
      TeamSmallManager manager5 = TeamSmallManager.getInstance();
      List<TeamSmall> teamSmallTnameList = manager5.findTnameByMnum(member.getNum());
      
//      for(int i = 0; i < teamSmallNameMentorList.size(); i++)
//    	  teamSmallNameMentorList.get(i).getName()
      
      List<Mentor> mentorList = new ArrayList<>();
      
      for(int i = 0; i < teamSmallTnameList.size(); i++) {
    	  Mentor mentorname = manager2.findMentor(teamSmallTnameList.get(i).getMentorNum());
    	  mentorList.add(mentorname);
    	  log.debug(" {}", teamSmallTnameList.get(i).getMentorNum());
      }
     
      request.setAttribute("mentorList", mentorList);
      ReviewManager manager3 = ReviewManager.getInstance();
      
      String mentorid = request.getParameter("mentorid");
      log.debug("mentorid {}", mentorid);
      Mentor mentor = manager2.findMentorById1(mentorid);
      
      Review review = new Review(member.getNum(), 
     		 		mentor.getNum(), 
     		 		request.getParameter("revtitle"), 
     		 		request.getParameter("revcontent"),
     		 		request.getParameter("revdate")
     		 		);
      
      manager3.create(review);
      
      request.setAttribute("review", review);
      StarManager manager4 = StarManager.getInstance();
      Star star = new Star(mentor.getNum(), 
    		  Integer.parseInt(request.getParameter("SATISFACTION")), Integer.parseInt(request.getParameter("PARTICIPATION")), 
    		Integer.parseInt(request.getParameter("PREPARATION"))
    		  );
      
      //request.setAttribute("star", star);
      manager4.create(star);
      
      float startotal = manager4.sumOfStar(star.getMentorNum());
      log.debug("{}", star.getMentorNum());
      log.debug("{}", startotal);
      mentor.setStar(startotal);
      manager2.updateStar(mentor);
      
      try{
    	  
          
          return "redirect:/review/reviewList";
         
      } catch(Exception e) {
         request.setAttribute("updateFailed", true);
         request.setAttribute("exception", new IllegalStateException("�ٸ� ������� ������ ������ �� �����ϴ�."));            
         return "/mentor/mentorJoin.jsp";    
      }
      
    }
}