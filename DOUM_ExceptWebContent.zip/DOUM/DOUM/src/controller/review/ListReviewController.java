package controller.review;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils; //�α��εǸ� �� �� �ִ� ȭ��
import model.*;
import model.service.*;

public class ListReviewController implements Controller {
	
	private static final Logger log = LoggerFactory.getLogger(ListReviewController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
		// �α��� ���� Ȯ��
    	if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";		// login form ��û���� redirect
        }
    
    	ReviewManager manager = ReviewManager.getInstance();
		
		List<Review> reviewList = manager.findReviewList();
	
		
		request.setAttribute("reviewList", reviewList);				
		request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		

		return "/review/reviewList.jsp";        
    }
}
