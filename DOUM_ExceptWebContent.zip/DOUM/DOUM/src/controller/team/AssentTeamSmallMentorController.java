package controller.team;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.Member;
import model.Mentee;
import model.Mentor;
import model.TeamSmall;
import model.Waiting;
import model.service.MemberManager;
import model.service.MenteeManager;
import model.service.MentorManager;
import model.service.TeamSmallManager;
import model.service.WaitingManager;

public class AssentTeamSmallMentorController implements Controller {
   
    private static final Logger log = LoggerFactory.getLogger(AssentTeamSmallMentorController.class);

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";      
        }

       request.setAttribute("curUserId", 
                MemberSessionUtils.getMemberFromSession(request.getSession()));      
         String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());

         request.setAttribute("Teamname", 
               TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession())); 
         String Teamname = TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession());
         
         HttpSession session = request.getSession();
         session.setAttribute(TeamSmallListSessionUtils.TEAMSMALLList_SESSION_KEY, Teamname);
         
        String Teamnameparameter = Teamname;
         
         TeamSmallManager manager3 = TeamSmallManager.getInstance();
         TeamSmall teamSmall = manager3.findTeamSmallByNAME(Teamnameparameter);
        
         request.setAttribute("TeamSmall", teamSmall);
      
       MemberManager manager = MemberManager.getInstance();
       
       String naming = request.getParameter("mname");
       log.debug("mname {}", naming);
       
       
       
        Member member = manager.findMemberByName(request.getParameter("mname"));
        
          request.setAttribute("member", member);
          
    
          MenteeManager manager2 = MenteeManager.getInstance();
          Mentee mentee = new Mentee(teamSmall.getNum(), member.getNum());
          mentee.setMember(member);
          mentee.setTeamSmall(teamSmall);
          
          
          MentorManager manager5 = MentorManager.getInstance();
          
          Mentor mentor = manager5.findMentor(teamSmall.getMentorNum());
          request.setAttribute("mentor", mentor);
          
          String TeamMentorId = mentor.getMember().getId();
          
          log.debug(" 멘토아이디 {}", TeamMentorId);
          
          if (curUserId.equals(TeamMentorId)) {
             manager2.create(mentee);

             log.debug(" 멘토일 경우 {}", mentee.getTnum());
              request.setAttribute("mentee", mentee);   
              
              WaitingManager manager4 = WaitingManager.getInstance();
              Waiting waiting = manager4.findWaitNum(teamSmall.getNum(), member.getNum());
     
              waiting.setWaiting(waiting);
              
              manager4.remove(teamSmall.getNum(), waiting.getWaitnum());

              return "redirect:/team/teamSmallList";      
          
           }

          try {
 
             
    
             return "redirect:/team/teamSmallList";   
      } catch (Exception e) {      
            request.setAttribute("registerFailed", true);
         request.setAttribute("exception", e);
         

         return "redirect:/team/teamSmallList";   
      }
    }
}