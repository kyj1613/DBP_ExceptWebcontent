package controller.team;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.Controller;
import model.*;
import model.service.MenteeManager;
import model.service.RentHisManager;
import model.service.ReportManager;
import model.service.TeamSmallManager;
import model.service.WaitingManager;

public class DeleteTeamSmallController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(DeleteTeamSmallController.class);
    
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	
    	request.setAttribute("Teamname", 
     		   TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession()));      
    	
    	TeamSmallManager manager = TeamSmallManager.getInstance();
    	
    	String Teamname = TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession());
    	String Teamnameparameter = Teamname;
 
    	MenteeManager manager2 = MenteeManager.getInstance();
    	WaitingManager manager3 = WaitingManager.getInstance();
    	RentHisManager manager4 = RentHisManager.getInstance();
    	ReportManager manager5 = ReportManager.getInstance();
    	
    	
        try {
    	TeamSmall teamSmall = manager.findTeamSmallByNAME(Teamnameparameter);
    	
    	
    	List<Mentee> menteeList = manager2.findMenteeList(teamSmall.getNum());
    	List<Waiting> waitingList = manager3.findWaitingList(teamSmall.getNum());
    	
    	
    	
    	
    	List<RentHis> rentHisList = manager4.findRentHisTnumList(teamSmall.getNum());
    	List<Report> reportList = manager5.findReportList(teamSmall.getNum());
    	
    	for(int i = 0; i < menteeList.size(); i++)
    		manager2.removeByTnum(menteeList.get(i));
    	
    	for(int i = 0; i < waitingList.size(); i++)
    		manager3.removeWaiting(waitingList.get(i));
    	
    	for(int i = 0; i < rentHisList.size(); i++)
    		manager4.removeTnum(rentHisList.get(i));
    	
    	for(int i = 0; i < reportList.size(); i++)
    		manager5.removeTnum(reportList.get(i));
    	
    	
    	
    	manager.remove(teamSmall.getNum());
    	
    	
    	return "redirect:/team/teamSmallList";		
        
		} catch (Exception e) {		
        request.setAttribute("registerFailed", true);
		request.setAttribute("exception", e);
		return "/team/teamSmallList.jsp";
	}
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    	
    }
//		int deleteTeamSmallNum = Integer.parseInt(request.getParameter("teamNum"));
//		int deleteTeamSmallMentorNum = Integer.parseInt(request.getParameter("mentorNum"));
//    	log.debug("Delete TeamSmall : {}", deleteTeamSmallNum);
//    	
////    	String deleteId = request.getParameter("userId");
////    	log.debug("Delete Mentor : {}", deleteId);
//
//		TeamSmallManager manager = TeamSmallManager.getInstance();
//    	int curMentorNum = MentorSessionUtils.getMentorFromSession(request.getSession());		
//			
//    	
//    	
//    	
//		if (
////				curUserId.equals("admin") && 	// �α����� ����ڰ� �������̰� 	
////			 !deleteId.equals("admin")		// ���� ����� �Ϲ� ������� ���, 
////			   || 							// �Ǵ� 
//			  	// �α����� ����ڰ� �����ڰ� �ƴϰ� 
//				deleteTeamSmallMentorNum == curMentorNum)  { // ���� ����� ������ ���
//				
//			manager.remove(deleteTeamSmallNum);			// �� ���� ����
////			if (curMentorNum.equals("admin")) 
////				return "redirect:/user/list";		// ����ڸ���Ʈ�� �̵�
////			else 
//				return "redirect:/team/teamSmallList";		
//		}
//		
//		/* ������ �Ұ����� ��� */
////		User user = manager.findUser(deleteId);	// ����� ���� �˻�
////		request.setAttribute("user", user);						
////		request.setAttribute("deleteFailed", true);
////		String msg = (curUserId.equals("admin")) 
////				   ? "�ý��� ������ ������ ������ �� �����ϴ�."		
////				   : "�ٸ� ������� ������ ������ �� �����ϴ�.";													
////		request.setAttribute("exception", new IllegalStateException(msg));            
//		return "/team/teamSmallList.jsp";		// ����� ���� ȭ������ �̵� (forwarding)	
//	}
}
