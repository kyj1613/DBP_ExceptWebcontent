package controller.team;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.service.TeamSmallManager;
import model.service.WaitingManager;
import model.service.MemberManager;
import model.service.MenteeManager;
import model.service.MentorManager;
import model.Member;
import model.Mentee;
import model.Mentor;
import model.TeamSmall;
import model.Waiting;

public class DetailTeamSmallController implements Controller {
   private static final Logger log = LoggerFactory.getLogger(DetailTeamSmallController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         

       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";     
        }

       request.setAttribute("curUserId", MemberSessionUtils.getMemberFromSession(request.getSession()));      
       String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
       
       HttpSession session = request.getSession();///
       
       String Teamname;
       if(request.getMethod().equals("GET")) {
             Teamname = (String)request.getParameter("Teamname");
             log.debug("Teamname1~~{} ",Teamname );
         }
         else {
            Teamname = (String)request.getAttribute("Teamname");
            log.debug("Teamname1~~{} ",Teamname );
         }
         
       session.setAttribute(TeamSmallListSessionUtils.TEAMSMALLList_SESSION_KEY, Teamname); 
       request.setAttribute("Teamname", TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession()));      
          
       
   
       
        MentorManager mentorManager = MentorManager.getInstance();
        MenteeManager menteeManager = MenteeManager.getInstance();
        
        
        TeamSmallManager tsManager = TeamSmallManager.getInstance();
        TeamSmall ts = tsManager.findTeamSmallByNAME(Teamname);
        String fieldname = tsManager.findTeamSmallFieldByNAME(Teamname);
          
        int tnum = ts.getNum();
        log.debug("Teamname~~{}num ",tnum);
    
         WaitingManager manager6 = WaitingManager.getInstance();
         List<Waiting> waitingList = manager6.findWaitingList(tnum);
         request.setAttribute("waitingList", waitingList);            

          MemberManager memberManager = MemberManager.getInstance();
          Member member = memberManager.findMember(curUserId);

/*        
        TeamSmall teamSmallA = tsManager.findTeamSmall(tnum);*/
     //  teamSmallA.getName();
        
         List<Mentee> menteeList = null;
      try {
/*         TeamSmall teamSmall = tsManager.findTeamSmallByNAME(Teamname); */
         /*int mentorNum = teamSmall.getMentorNum();*/
         int mentorNum = ts.getMentorNum();
         Mentor mentor = mentorManager.findMentor(mentorNum);
         log.debug("mentor�� mnum {}  ", mentor.getMember().getNum());
         request.setAttribute("mentor", mentor);
//         log.debug("{});"
//               + "; mentor";
         menteeList = menteeManager.findMenteeList(tnum);   
         
         
         
         request.setAttribute("isWaiting", "false");
          for(int i = 0; i < waitingList.size(); i++) {
            int mnum = waitingList.get(i).getMnum();
            
            if(mnum == member.getNum()) {
                request.setAttribute("isWaiting", "true");
                break;
             }
          }
          
         log.debug("isWaiting {}  ",request.getAttribute("isWaiting"));
          

         request.setAttribute("isMentee", "false");        
       for(int j = 0; j < menteeList.size(); j++) {
          if(menteeList.get(j).getMnum() == member.getNum()) {
             request.setAttribute("isMentee", "true");
             break;
           }
          }
       log.debug("isMentee {}  ",request.getAttribute("isMentee"));
       request.setAttribute("isMentor", "false");        
       if(mentor.getMember().getNum() == member.getNum())
          request.setAttribute("isMentor", "true");        
       log.debug("isMentor {}  ",request.getAttribute("isMentor"));
       
       request.setAttribute("isFull", "false");
       if(menteeManager.countMentee(tnum) == 4)
          request.setAttribute("isFull", "true");
           
       
         
      } catch (Exception e) {            
           return "redirect:/team/teamSmallList";
      }    
      
      request.setAttribute("ts", ts);
      request.setAttribute("fieldname", fieldname);
      request.setAttribute("ts", ts);     
      request.setAttribute("MenteeList", menteeList);   
      return "/team/teamSmallDetail.jsp";          
    }
} 
