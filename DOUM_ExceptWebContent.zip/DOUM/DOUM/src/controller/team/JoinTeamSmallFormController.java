package controller.team;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.Controller;
import controller.member.MemberSessionUtils;
import model.Mentor;
import model.TeamSmall;
import model.service.ExistingTeamException;
import model.service.MentorManager;
import model.service.TeamSmallManager;

public class JoinTeamSmallFormController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(JoinTeamSmallFormController.class);

    
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
       
       request.setAttribute("curUserId", 
             MemberSessionUtils.getMemberFromSession(request.getSession()));      
      String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
      
        String teamname = request.getParameter("teamname");
        
        //log.debug("teamname , {}",request.getParameter("teamname"));
        HttpSession session = request.getSession();
        session.setAttribute(TeamSmallSessionUtils.TEAMSMALL_SESSION_KEY, teamname);
        
        log.debug("~~ , {}", teamname);
        
//        request.setAttribute("teamname", 
//                TeamSmallSessionUtils.getTeamSmallFromSession(request.getSession()));
//        teamname = TeamSmallSessionUtils.getTeamSmallFromSession(request.getSession());
        
       try{
          MentorManager manager = MentorManager.getInstance();
          
          Mentor mentor = null;
          mentor = manager.findMentorById1(curUserId);

          request.setAttribute("mentor", mentor);
          log.debug("~~ , {}", mentor.getNum());
          
          
          
            TeamSmallManager manager3 = TeamSmallManager.getInstance();
            log.debug("~~ , {}", request.getParameter("checkfield"));
            //log.debug("teamname , {}",request.getParameter("teamname"));
            
            
            
            TeamSmall teamSmall  = new TeamSmall(teamname,       
                 Integer.parseInt(request.getParameter("checkfield")),
                 request.getParameter("meetingLoc"),
                 request.getParameter("endDate"),
                 mentor.getNum()
                  );

            manager3.create(teamSmall);
            
            log.debug("Create TeamSmall : {}", teamSmall);
            return "redirect:/team/teamSmallList";
            
      } catch (ExistingTeamException e) {      
            request.setAttribute("registerFailed", true);
         request.setAttribute("exception", e);
         return "/team/teamSmallJoin.jsp";
      }
    }
}