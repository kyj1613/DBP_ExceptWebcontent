package controller.team;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.Controller;
import controller.member.MemberSessionUtils;
import model.Member;
import model.Mentee;
import model.TeamSmall;
import model.service.MemberManager;
import model.service.MenteeManager;
import model.service.TeamSmallManager;

public class LeaveTeamController implements Controller {
	
    private static final Logger log = LoggerFactory.getLogger(LeaveTeamController.class);

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
    	
    	
    	request.setAttribute("Teamname", 
      		   TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession()));      
     	
    	request.setAttribute("curUserId", 
                MemberSessionUtils.getMemberFromSession(request.getSession()));      
    	
    	
     	TeamSmallManager manager = TeamSmallManager.getInstance();
     	MemberManager manager2 = MemberManager.getInstance();
     	MenteeManager manager3 = MenteeManager.getInstance();
     	
     	String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
     	String Teamname = TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession());
     	String Teamnameparameter = Teamname;

         try {
     	TeamSmall teamSmall = manager.findTeamSmallByNAME(Teamnameparameter);
     	Member member = manager2.findMember(curUserId);
     	
       
     	 Mentee mentee = new Mentee(teamSmall.getNum(), member.getNum());
         mentee.setMember(member);
         mentee.setTeamSmall(teamSmall);
         
     	manager3.remove(mentee);
     	
     	
     	return "redirect:/team/teamSmallList";		
         
 		} catch (Exception e) {		
         request.setAttribute("registerFailed", true);
 		request.setAttribute("exception", e);
 		request.setAttribute("exception", new IllegalStateException("����� �� ���� ��Ƽ�� �ƴ϶� ��Ƽ ������ ���� �����."));  
 	
 		return "/main/mainPage.jsp";
 	}
    }
}
     	
 