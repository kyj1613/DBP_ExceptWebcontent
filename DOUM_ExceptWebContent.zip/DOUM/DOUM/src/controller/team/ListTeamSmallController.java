package controller.team;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import controller.member.MemberSessionUtils; //�α��εǸ� �� �� �ִ� ȭ��

import model.TeamSmall;
import model.service.TeamSmallManager;

public class ListTeamSmallController implements Controller {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
		// �α��� ���� Ȯ��
    	if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";		// login form ��û���� redirect
        }
    	
    	request.setAttribute("curUserId", 
    			MemberSessionUtils.getMemberFromSession(request.getSession()));		
    	
    	
    	TeamSmallManager manager7 = TeamSmallManager.getInstance();
		List<TeamSmall> teamSmallList = manager7.findTeamSmallList();
	
		request.setAttribute("teamSmallList", teamSmallList);				
		request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		

		return "/team/teamSmallList.jsp";        
    }
}
