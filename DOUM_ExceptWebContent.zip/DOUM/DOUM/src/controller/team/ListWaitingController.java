package controller.team;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils; 
import model.TeamSmall;
import model.Waiting;
import model.service.TeamSmallManager;
import model.service.WaitingManager;

public class ListWaitingController implements Controller {
	
	
	private static final Logger log = LoggerFactory.getLogger(ListWaitingController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)   throws Exception {
     
       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";     
        }
    
       TeamSmall ts = null;
       TeamSmallManager tsmanager = TeamSmallManager.getInstance();
      
      
      
      String Teamname = request.getParameter("Teamname");
  
      try {
	      ts = tsmanager.findTeamSmallByNAME(Teamname);
	      int tnum = ts.getNum();
	
	       WaitingManager manager = WaitingManager.getInstance();
	      List<Waiting> waitingList = manager.findWaitingList(tnum);
	      
	      request.setAttribute("waitingList", waitingList);            
	      request.setAttribute("curUserId", 
	            MemberSessionUtils.getMemberFromSession(request.getSession())); 
	      
	     
	      HttpSession session = request.getSession();
	      session.setAttribute(TeamSmallSessionUtils.TEAMSMALL_SESSION_KEY, Teamname);
	   
	      
	      request.setAttribute("Teamname", 
	     	       TeamSmallSessionUtils.getTeamSmallFromSession(request.getSession())); 
	     
	      
   
      } catch (Exception e) {            
          return "redirect:/mentor/mentorList";
     } 
      return "/team/WaitingPage.jsp";        
    }
}