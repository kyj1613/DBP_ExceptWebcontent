package controller.team;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.Controller;
import controller.member.MemberSessionUtils;
import model.Member;
import model.TeamSmall;
import model.Waiting;
import model.service.MemberManager;
import model.service.TeamSmallManager;
import model.service.WaitingManager;

public class RequestTeamSmallController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(RequestTeamSmallController.class);

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
   
       request.setAttribute("Teamname", 
                 TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession()));      
       
       String Teamname = TeamSmallListSessionUtils.getTeamSmallListFromSession(request.getSession());
   
       request.setAttribute("curUserId", MemberSessionUtils.getMemberFromSession(request.getSession()));      
        String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
       
       MemberManager manager = MemberManager.getInstance();
        Member member = manager.findMember(curUserId);
        request.setAttribute("member", member);
      
      
        TeamSmallManager manager3 = TeamSmallManager.getInstance();
        TeamSmall teamSmall = manager3.findTeamSmallByNAME(Teamname);
        request.setAttribute("teamSmall", teamSmall);
        
        int waitingteamnum = teamSmall.getNum();
   
        WaitingManager manager5 = WaitingManager.getInstance();
        int waitingnum = manager5.findLastWaitNum(waitingteamnum);
        log.debug("waitingnum {}", waitingnum);
        int waitingNumNew = waitingnum + 1;
       
        Waiting waiting = new Waiting(
              waitingNumNew, member.getName(), member.getNum(), 
               waitingteamnum);

        waiting.setMember(member);
        waiting.setTeamSmall(teamSmall);
        manager5.create(waiting);

       
       
      try {
         
           return "redirect:/team/teamSmallDetailRequest";      
           
      } catch (Exception e) {      
            request.setAttribute("registerFailed", true);
         request.setAttribute("exception", e);
         
         return "/team/teamSmallRequest.jsp";
      }
    }
} 
