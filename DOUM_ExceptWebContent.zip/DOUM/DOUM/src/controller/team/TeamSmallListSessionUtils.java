
package controller.team;

import javax.servlet.http.HttpSession;

public class TeamSmallListSessionUtils {
    public static final String TEAMSMALLList_SESSION_KEY = "team";

    public static String getTeamSmallListFromSession(HttpSession session) {
        String name = (String)session.getAttribute(TEAMSMALLList_SESSION_KEY);
        return name;
    }//�� ����Ʈ���� ���̸� �����ؼ� �ѱ�� ����

    
    
    public static boolean isLogined(HttpSession session) {
        if (getTeamSmallListFromSession(session) != null) {
            return true;
        }
        return false;
    }
  
}
