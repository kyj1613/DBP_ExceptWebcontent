
package controller.team;

import javax.servlet.http.HttpSession;

public class TeamSmallSessionUtils {
    public static final String TEAMSMALL_SESSION_KEY = "team";

    public static String getTeamSmallFromSession(HttpSession session) {
        String name = (String)session.getAttribute(TEAMSMALL_SESSION_KEY);
        return name;
    }//�� ������ �� ���̸� �����ؼ� �ѱ�� ����

    public static String getTeamSmallFromSession1(HttpSession session) {
        String name = (String)session.getAttribute(TEAMSMALL_SESSION_KEY);
        return name;
    }
    
    public static boolean isLogined(HttpSession session) {
        if (getTeamSmallFromSession(session) != null) {
            return true;
        }
        return false;
    }
   
}
