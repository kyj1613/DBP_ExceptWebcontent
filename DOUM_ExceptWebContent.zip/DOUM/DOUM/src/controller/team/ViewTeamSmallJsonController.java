package controller.team;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import controller.Controller;
import controller.DispatcherServlet;
import model.TeamSmall;
import model.service.MenteeManager;
import model.service.TeamSmallManager;

public class ViewTeamSmallJsonController implements Controller {
	private static final Logger logger = LoggerFactory.getLogger(ViewTeamSmallJsonController.class);

	@Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         
       
		List<TeamSmall> teamSmallList = new ArrayList<TeamSmall>();
		TeamSmallManager manager = TeamSmallManager.getInstance();
		MenteeManager manager2 = MenteeManager.getInstance();
      
		List<TeamSmall> teamList = manager.findTeamSmallList();
		List<Integer> teamNum = new ArrayList<Integer>();
		for(TeamSmall team : teamList) {
			teamNum.add(team.getNum());
		}
      
		String tlStatus = request.getParameter("tlStatus");          
		logger.debug("tlStatus : {}", tlStatus);
		if(tlStatus.equals("avail")) {
			for(int i = 0; i < teamNum.size(); i++) {
				if((manager2.countMentee(teamNum.get(i)) < 3)) { 
                  //|| (manager2.countMentee(teamNum.get(i)) > 4)) {
               teamSmallList.add(teamList.get(i));
            }
            else continue;
         }
      }
      else {
         for(int i = 0; i < teamNum.size(); i++) {
            if((manager2.countMentee(teamNum.get(i)) >= 3)) { 
               teamSmallList.add(teamList.get(i));
            }
            else continue;
         }
      }
		
      // Jackson�� �̿��Ͽ� ��� ��ü���� JSON �ؽ�Ʈ�� ��ȯ
      ObjectMapper mapper = new ObjectMapper();
      String jsonString = mapper.writeValueAsString(teamSmallList);
      logger.debug("teamSmallList in JSON : {}", jsonString);

      // JSON �ؽ�Ʈ�� �����ϴ� response message ����
      response.setContentType("application/json;charset=utf-8");   
      PrintWriter out = response.getWriter();
      out.println(jsonString);          
       
      return null;   // uri ��� null�� ���� -> DispatcherServlet���� ��û ó�� ���� 
    }
}