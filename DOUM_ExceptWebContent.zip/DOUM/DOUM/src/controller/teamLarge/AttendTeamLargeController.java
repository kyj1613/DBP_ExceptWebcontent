package controller.teamLarge;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.Controller;
import controller.member.MemberSessionUtils;
import model.Member;
import model.Mentor;
import model.TeamLarge;
import model.TeamLargeHis;
import model.TeamSmall;
import model.service.ExistingTeamException;
import model.service.*;
import model.service.MentorManager;
import model.service.TeamLargeHisManager;
import model.service.TeamLargeManager;
import model.service.TeamSmallManager;

public class AttendTeamLargeController implements Controller {
    private static final Logger log = LoggerFactory.getLogger(AttendTeamLargeController.class);

    
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
       
       request.setAttribute("curUserId", 
             MemberSessionUtils.getMemberFromSession(request.getSession()));      
      String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
      
        
        
        //log.debug("teamname , {}",request.getParameter("teamname"));
      request.setAttribute("teamname", 
               TeamLargeListSessionUtils.getTeamLargeListFromSession(request.getSession()));      
   
        String teamname = TeamLargeListSessionUtils.getTeamLargeListFromSession(request.getSession());      
        
        
        
        log.debug("~~ , {}", teamname);
        
//        request.setAttribute("teamname", 
//                TeamSmallSessionUtils.getTeamSmallFromSession(request.getSession()));
//        teamname = TeamSmallSessionUtils.getTeamSmallFromSession(request.getSession());
        
       try{
          
            MemberManager manager = MemberManager.getInstance();
            Member member = manager.findMember(curUserId);
            
            TeamLargeManager manager2 = TeamLargeManager.getInstance();
            TeamLarge teamLarge = manager2.findTeamLargeByName(teamname);
            
            TeamLargeHisManager manager3 = TeamLargeHisManager.getInstance();
            
            
            TeamLargeHis teamLargeHis  = new TeamLargeHis(teamLarge.getNum(),       
                 member.getNum()
                  );
            
            
            
            manager3.create(teamLargeHis);
            
            log.debug("Create TeamSmall : {}", teamLargeHis);
            return "redirect:/teamLarge/teamLargeDetailAttend";
            
      } catch (ExistingTeamException e) {      
            request.setAttribute("registerFailed", true);
         request.setAttribute("exception", e);
         return "/team/teamSmallJoin.jsp";
      }
    }
} 
