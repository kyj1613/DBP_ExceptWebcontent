package controller.teamLarge;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.MemberSessionUtils;
import model.service.TeamLargeManager;
import model.service.MemberManager;
import model.service.MentorManager;
import model.service.TeamLargeHisManager;
import controller.teamLarge.TeamLargeListSessionUtils;
import model.Member;
import model.Mentor;
import model.TeamLarge;


public class DetailTeamLargeController implements Controller {
   private static final Logger log = LoggerFactory.getLogger(DetailTeamLargeController.class);
    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         

       if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";     
        }

       
      // TeamSmallManager manager = TeamSmallManager.getInstance();
       String Teamname = request.getParameter("Teamname");
       
       request.setAttribute("curUserId", 
               MemberSessionUtils.getMemberFromSession(request.getSession()));     
       String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
       
       HttpSession session = request.getSession();///
       session.setAttribute(TeamLargeListSessionUtils.TEAMLARGEList_SESSION_KEY, Teamname); 
       log.debug("Teamname~~{} ",Teamname );
       request.setAttribute("Teamname", 
                TeamLargeListSessionUtils.getTeamLargeListFromSession(request.getSession()));      
          
       
   
   
      MentorManager manager2 = MentorManager.getInstance();
                 
      TeamLargeManager manager4 = TeamLargeManager.getInstance();
            
      TeamLarge teamLarge = manager4.findTeamLargeByName(Teamname); 
      log.debug("Teamname~~{} ", teamLarge.getNum());
      String teamfield = manager4.findTeamLargeFieldByName(Teamname);
      
      TeamLargeHisManager manager3 = TeamLargeHisManager.getInstance();
      
      MemberManager memberManager = MemberManager.getInstance();
      Member member = memberManager.findMember(curUserId);
      
      List<TeamLarge> teamLargeList = manager4.findTnameByMnum(member.getNum());
      
      request.setAttribute("isWaiting", "false");
      for(int i = 0; i < teamLargeList.size(); i++) {
         log.debug("Tnum~~{} ", teamLargeList.get(i).getNum());
         if(teamLarge.getNum() == teamLargeList.get(i).getNum()) {
            request.setAttribute("isWaiting", "true");
            break;
         }
      }
      
      log.debug("isWaiting {} ", request.getAttribute("isWaiting"));
      
      int counting = manager3.countLimit(teamLarge.getNum());
      int mentorNum = teamLarge.getMentorNum();
      Mentor mentor = manager2.findMentor(mentorNum);
      
      request.setAttribute("isMentor", "false");        
       if(mentor.getMember().getNum() == member.getNum())
          request.setAttribute("isMentor", "true");        
       log.debug("isMentor {}  ",request.getAttribute("isMentor"));
       
      
      request.setAttribute("teamfield", teamfield);
      request.setAttribute("counting", counting);
      request.setAttribute("mentor", mentor);
      request.setAttribute("teamLarge", teamLarge); 
       
        
      try {
         
      } catch (Exception e) {            
           return "redirect:/team/teamLargeList";
      }    
      
         
    
      return "/teamLarge/teamLargeDetail.jsp";          
    }
} 
