package controller.teamLarge;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.Controller;
import controller.member.*;

import model.*;

import model.service.*;


public class JoinTeamLargeController implements Controller {
  
	private static final Logger log = LoggerFactory.getLogger(JoinTeamLargeController.class);
   public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
	   if (!MemberSessionUtils.isLogined(request.getSession())) {
           return "redirect:/member/login/form";      
       }
	   
	   request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		
      String curUserId = MemberSessionUtils.getMemberFromSession(request.getSession());
      
      try{
         MentorManager manager = MentorManager.getInstance();
         Mentor mentor = manager.findMentorById1(curUserId);
         
         TeamLargeManager manager2 = TeamLargeManager.getInstance();
         TeamLarge teamLarge = new TeamLarge(
        
        		 request.getParameter("tname"),
        		 mentor.getNum(),
        		 request.getParameter("start_date"),
        		 Integer.parseInt(request.getParameter("field1")),
        		 request.getParameter("meeting_loc"),
        		 Integer.parseInt(request.getParameter("limit"))
        		 );
         
         manager2.create(teamLarge);
         
         
         return "redirect:/teamLarge/teamLargeList";
         
      } catch(Exception e) {
         request.setAttribute("updateFailed", true);
         request.setAttribute("exception", new IllegalStateException("������ �� �����ϴ�."));            
         return "/mentor/mentorJoin.jsp";    
      }
     
    }
}