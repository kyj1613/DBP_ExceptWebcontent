package controller.teamLarge;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import controller.member.MemberSessionUtils; //�α��εǸ� �� �� �ִ� ȭ��

import model.*;
import model.service.*;

public class ListTeamLargeController implements Controller {

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
		// �α��� ���� Ȯ��
    	if (!MemberSessionUtils.isLogined(request.getSession())) {
            return "redirect:/member/login/form";		// login form ��û���� redirect
        }
    	
    	request.setAttribute("curUserId", 
    			MemberSessionUtils.getMemberFromSession(request.getSession()));		
    	
    	
    	TeamLargeManager manager = TeamLargeManager.getInstance();
		List<TeamLarge> teamLargeList = manager.findTeamLargeList();
		
		request.setAttribute("teamLargeList", teamLargeList);				
		request.setAttribute("curUserId", 
				MemberSessionUtils.getMemberFromSession(request.getSession()));		

		return "/teamLarge/teamLargeList.jsp";        
    }
}
