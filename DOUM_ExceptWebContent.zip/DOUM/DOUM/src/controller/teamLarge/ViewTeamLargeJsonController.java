package controller.teamLarge;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.databind.ObjectMapper;

import controller.Controller;
import controller.team.ViewTeamSmallJsonController;
import model.TeamLarge;
import model.TeamSmall;
import model.service.MenteeManager;
import model.service.TeamLargeHisManager;
import model.service.TeamLargeManager;
import model.service.TeamSmallManager;

public class ViewTeamLargeJsonController implements Controller {
   private static final Logger logger = LoggerFactory.getLogger(ViewTeamSmallJsonController.class);

   @Override
    public String execute(HttpServletRequest request, HttpServletResponse response) throws Exception {         
       
      List<TeamLarge> teamLargeList = new ArrayList<TeamLarge>();
      TeamLargeManager manager = TeamLargeManager.getInstance();
      TeamLargeHisManager manager2 = TeamLargeHisManager.getInstance();
      
      List<TeamLarge> teamList = manager.findTeamLargeList();
      List<Integer> teamNum = new ArrayList<Integer>();
      for(TeamLarge team : teamList) {
         teamNum.add(team.getNum());
      }
      
      String tlStatus = request.getParameter("tlStatus");          
      logger.debug("tlStatus : {}", tlStatus);
    
      for(int i = 0; i < teamNum.size(); i++) {
         TeamLarge teamLarge = manager.findTeamLarge(teamNum.get(i));
         int limit = teamLarge.getLimit();
         if(tlStatus.equals("avail")) {
            if(manager2.countLimit(teamNum.get(i)) < limit){ 
               teamLargeList.add(teamList.get(i));
            }
            else continue;
         }
         else {
            if((manager2.countLimit(teamNum.get(i)) >= limit)) { 
               teamLargeList.add(teamList.get(i));
            }
            else continue;
         }
      }
             
      // Jackson�� �̿��Ͽ� ��� ��ü���� JSON �ؽ�Ʈ�� ��ȯ
      ObjectMapper mapper = new ObjectMapper();   
      String jsonString = mapper.writeValueAsString(teamLargeList);
      logger.debug("teamLargeList in JSON : {}", jsonString);

      // JSON �ؽ�Ʈ�� �����ϴ� response message ����
      response.setContentType("application/json;charset=utf-8");   
      PrintWriter out = response.getWriter();
      out.println(jsonString);          
       
      return null;   // uri ��� null�� ���� -> DispatcherServlet���� ��û ó�� ���� 
    }
}