package model;

public class Field {
	
	private int fnum;
	private String fname;
	
	public Field(int fnum, String fname) {
		this.fnum = fnum;
		this.fname = fname;
	}
	public Field() {
		// TODO Auto-generated constructor stub
	}
	public int getFnum() {
		return fnum;
	}
	public void setFnum(int fnum) {
		this.fnum = fnum;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	
}
