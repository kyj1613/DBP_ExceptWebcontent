package model;

public class Location {
	private int roomnum;
	private int locnum;
	private String locname;
	private String address;
	private String city;
	
	public Location() {}
	public Location(int roomnum, int locnum, String locname, String city, String address) {
	      // TODO Auto-generated constructor stub
	      this.roomnum = roomnum;
	      this.locnum = locnum;
	      this.locname = locname;
	      this.city = city;
	      this.address = address;
	   }

	public Location(int locnum, String locname) {
	      // TODO Auto-generated constructor stub
	      this.locnum = locnum;
	      this.locname = locname;
	      
	   }
	
	
	public int getRoomnum() {
		return roomnum;
	}
	public void setRoomnum(int roomnum) {
		this.roomnum = roomnum;
	}
	public int getLocnum() {
		return locnum;
	}
	public void setLocnum(int locnum) {
		this.locnum = locnum;
	}
	public String getLocname() {
		return locname;
	}
	public void setLocname(String locname) {
		this.locname = locname;
	}
	public String getCity() {
	      return city;
	   }

	   public void setCity(String city) {
	      this.city = city;
	   }

	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
}
