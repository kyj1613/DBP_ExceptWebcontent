package model;

import java.io.Serializable;
import java.util.List;

public class Member implements Serializable {
   
   private static final long serialVersionUID = 1L;
   private int num;
   private String id;
   private String password;
   private String name;
   private String sex;
   private String nickname;
   private String tel;
   private String birth;
   private String email;
   private Field fieldN;
   private List<Integer> field;
   
   public Member(String id, String pwd, String name, String sex, String nickname, String tel, String birth, String email, List<Integer> field) {
	   
      this.id = id;
      this.password = pwd;
      this.name = name;
      this.sex = sex;
      this.nickname = nickname;
      this.tel = tel;
      this.birth = birth;
      this.email = email;
      this.field = field;
   }
   
   public Member() {

   }
   public int getNum() {
      return num;
   }
   public void setNum(int num) {
      this.num = num;
   }
   public String getId() {
      return id;
   }
   public void setId(String id) {
      this.id = id;
   }
   public String getPassword() {
      return password;
   }
   public void setPassword(String password) {
      this.password = password;
   }
   public String getNickname() {
      return nickname;
   }
   public void setNickname(String nickname) {
      this.nickname = nickname;
   }
   public String getSex() {
      return sex;
   }
   public void setSex(String sex) {
      this.sex = sex;
   }
   public String getTel() {
      return tel;
   }
   public void setTel(String tel) {
      this.tel = tel;
   }
   public String getBirth() {
      return birth;
   }
   public void setbirth(String birth) {
      this.birth = birth;
   }
   public String getEmail() {
      return email;
   }
   public void setEmail(String email) {
      this.email = email;
   }
   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public Field getFieldN() {
	   return fieldN;
   }
   public void setFieldN(Field fieldN) {
	   this.fieldN = fieldN;
   }
   public void setField(List<Integer> field) {
	   this.field = field;
   }
   public List<Integer> getField() {
	   return field; 
   }
      
   /* ��й�ȣ �˻� */
   public boolean matchPassword(String password) {
      if (password == null) {
         return false;
      }
      return this.password.equals(password);
   }
   
   public boolean isSameUser(String userid) {
        return this.id.equals(id);
    }
}