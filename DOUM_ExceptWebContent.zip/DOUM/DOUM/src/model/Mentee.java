package model;

public class Mentee {
   private int tnum;
   private int mnum;
   private Member member;
   private TeamSmall teamSmall;
   
   public Mentee(int tnum, int mnum) {
      this.tnum= tnum;
      this.mnum = mnum;
      member = new Member();
   }
   
   public Mentee() {
   // TODO Auto-generated constructor stub
}

public int getTnum() {
      return tnum;
   }
   public void setTnum(int tnum) {
      this.tnum = tnum;
   }
   public int getMnum() {
      return mnum;
   }
   public void setMnum(int mnum) {
      this.mnum = mnum;
   }
   public Member getMember() {
      return member;
   }
   public void setMember(Member member) {
      this.member = member;
   }

   public TeamSmall getTeamSmall() {
      return teamSmall;
   }

   public void setTeamSmall(TeamSmall teamSmall) {
   // TODO Auto-generated method stub
     this.teamSmall=teamSmall;
   }   
   
}