package model;

public class Mentor {
	
   public int num;
   private String profile;
   private float star;
   private int history;
   private Member member;
   private Field field;
   private int field1;

   public Mentor() {
   }
   
   public Mentor(String profile, int field1) {
      member = new Member();
      field = new Field();
      this.profile = profile;
      this.field1 = field1;
   }
   public Mentor( String profile, int num, int field1) {
      member = new Member();
      this.num = num;
      this.profile = profile;
      this.field1 = field1;
   }
    public Mentor(int mentornum, String profile, int field1, float star) {
   // TODO Auto-generated constructor stub
    	field = new Field();
    	member = new Member();
       this.num = mentornum;
       this.profile = profile;
       this.field1 = field1;
       this.star = star;  
    }

   public int getNum() {
      return num;
   }
   public void setNum(int num) {
      this.num = num;
   }

   public String getProfile() {
      return profile;
   }
   public void setProfile(String profile) {
      this.profile = profile;
   }
   public Member getMember() {
      return member;
   }
   public void setMember(Member member) {
      this.member = member;
   }   
   public Field getField() {
	   return field;
	   
   }
   public void setField(Field field) {
	   
	   this.field = field;
	   
   }
   public int getField1() {
         return field1;
   }

   public void setField1(int field1) {
      this.field1 = field1;
   }

   public float getStar() {
      return star;
   }
   public void setStar(float star) {
      this.star = star;
   }
   
   public int getHistory() {
      return history;
   }
   
   public void setHistory(int history) {
      this.history = history;
   }
}