package model;

public class RentHis {
	private int roomnum;
	private int locnum;
	private int tnum;
	private String rdate;
	private String rtime;
	private int rnum;
	private TeamSmall teamSmall;
	
	public RentHis() {
		
	}
	

	public RentHis(int roomnum, int locnum, int tnum, String rdate, String rtime) {
		this.roomnum = roomnum;
		this.locnum = locnum;
		this.tnum = tnum;
		this.rdate = rdate;
		this.rtime = rtime;
	}
	
	public RentHis(int roomnum, int locnum, int tnum) {
		this.roomnum = roomnum;
		this.locnum = locnum;
		this.tnum = tnum;	
	}
	
	public RentHis(int roomnum, int locnum, int tnum, String rdate, String rtime, int rnum) {
		this.roomnum = roomnum;
		this.locnum = locnum;
		this.tnum = tnum;
		this.rdate = rdate;
		this.rtime = rtime;
		this.rnum = rnum;
	}
	
	public int getRoomnum() {
		return roomnum;
	}
	public void setRoomnum(int roomnum) {
		this.roomnum = roomnum;
	}
	public int getLocnum() {
		return locnum;
	}
	public void setLocnum(int locnum) {
		this.locnum = locnum;
	}
	public int getTnum() {
		return tnum;
	}
	public void setTnum(int tnum) {
		this.tnum = tnum;
	}
	public String getRdate() {
		return rdate;
	}
	public void setRdate(String rdate) {
		this.rdate = rdate;
	}
	public String getRtime() {
		return rtime;
	}
	public void setRtime(String rtime) {
		this.rtime = rtime;
	}
	public int getRnum() {
		return rnum;
	}
	public void setRnum(int rnum) {
		this.rnum = rnum;
	}

	public void setTeamSmall(TeamSmall teamSmall) {
		// TODO Auto-generated method stub
		this.teamSmall = teamSmall;
	}
	
	   public TeamSmall getTeamSmall() {
	      return teamSmall;
	   }
	
}
