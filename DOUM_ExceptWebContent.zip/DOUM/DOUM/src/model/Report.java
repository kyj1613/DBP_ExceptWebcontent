package model;

public class Report {
   private int rptnum;
   private int tnum;
   private String url;
   private String rptUpdate;
   private String url_rcp;
   private int expense;	//���ݾ�
   
   
   public Report() {
   }
   
   public Report(int tnum, String url, String rptUpdate, String url_rcp) {
      this.tnum = tnum;
      this.url = url;
      this.rptUpdate = rptUpdate;
      this.url_rcp = url_rcp;
   }

   public int getRptnum() {
      return rptnum;
   }

   public void setRptnum(int rptnum) {
      this.rptnum = rptnum;
   }

   public int getTnum() {
      return tnum;
   }

   public void setTnum(int tnum) {
      this.tnum = tnum;
   }

   public String getUrl() {
      return url;
   }

   public void setUrl(String url) {
      this.url = url;
   }

   public String getRptUpdate() {
      return rptUpdate;
   }

   public void setRptUpdate(String rptUpdate) {
      this.rptUpdate = rptUpdate;
   }

   public String getUrl_rcp() {
      return url_rcp;
   }

   public void setUrl_rcp(String url_rcp) {
      this.url_rcp = url_rcp;
   }
   
   public int getExpense() {
		return expense;
	}

	public void setExpense(int expense) {
		this.expense = expense;
	}

}