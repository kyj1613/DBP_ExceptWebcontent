package model;

public class Review {

   private int revnum;
   private int membernum;
   private int mentornum;
   private String revtitle;
   private String revcontent;
   private String revdate;
   private Member member;
   private Mentor mentor;
   private int cnt; //��ȸ��
   private Star star;
   
//   private String revAvailable;
   public Review() {}
   public Review(int revnum, int membernum, int mentornum, String revtitle, String revcontent, String revdate, int cnt) {
      // TODO Auto-generated constructor stub
      this.revnum = revnum;
      this.membernum = membernum;
      this.mentornum = mentornum;
      this.revtitle = revtitle;
      this.revcontent = revcontent;
      this.revdate = revdate;
      this.cnt = cnt;
   }
   public Review(int membernum, int mentornum, String revtitle, String revcontent, String revdate) {
	      // TODO Auto-generated constructor stub
	      
	      this.membernum = membernum;
	      this.mentornum = mentornum;
	      this.revtitle = revtitle;
	      this.revcontent = revcontent;
	      this.revdate = revdate;
	      
	   }
   public Review(int membernum, int mentornum, String revtitle, String revcontent, String revdate, int cnt) {
	      // TODO Auto-generated constructor stub
	   	
	      this.membernum = membernum;
	      this.mentornum = mentornum;
	      this.revtitle = revtitle;
	      this.revcontent = revcontent;
	      this.revdate = revdate;
	      this.cnt = cnt;
	   }
   public int getRevnum() {
      return revnum;
   }
   public void setRevnum(int revnum) {
      this.revnum = revnum;
   }
   public int getMembernum() {
      return membernum;
   }
   public void setMembernum(int membernum) {
      this.membernum = membernum;
   }
   public int getMentornum() {
      return mentornum;
   }
   public void setMentornum(int mentornum) {
      this.mentornum = mentornum;
   }
   public String getRevtitle() {
      return revtitle;
   }
   public void setRevtitle(String revtitle) {
      this.revtitle = revtitle;
   }
   public String getRevcontent() {
      return revcontent;
   }
   public void setRevcontent(String revcontent) {
      this.revcontent = revcontent;
   }
   public String getRevdate() {
      return revdate;
   }
   public void setRevdate(String revdate) {
      this.revdate = revdate;
   }
   public int getCnt() {
      return cnt;
   }
   public void setCnt(int cnt) {
      this.cnt = cnt;
   }
public Member getMember() {
	// TODO Auto-generated method stub
	return member;
}
public void setMember(Member member) {
    this.member = member;
 }   

public Mentor getMentor() {
	// TODO Auto-generated method stub
	return mentor;
}
public void setMentor(Mentor mentor) {
    this.mentor = mentor;
 }   
//   public String getRevAvailable() {
//      return revAvailable;
//   }
//   public void setRevAvailable(String revAvailable) {
//      this.revAvailable = revAvailable;
//   }   
	public Star getStar() {
	// TODO Auto-generated method stub
		return star;
	}
	public void setStar(Star star) {
	// TODO Auto-generated method stub
		this.star = star;
	}
}