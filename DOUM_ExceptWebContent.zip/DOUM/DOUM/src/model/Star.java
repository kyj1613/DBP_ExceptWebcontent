package model;

public class Star {
	private int revNum;
	private int mentorNum;
	private int satisfaction;
	private int participation;
	private int preparation;
	private float starTotal;
	
	public Star () {}
	public Star (int revNum, int mentorNum, int satisfaction, int participation, int preparation, float starTotal) {
		this.revNum = revNum;
		this.mentorNum = mentorNum;
		this.satisfaction = satisfaction; 
		this.participation = participation;
		this.preparation = preparation;
		this.starTotal = starTotal;	
	}
	public Star (int revNum, int mentorNum, int satisfaction, int participation, int preparation) {
		this.revNum = revNum;
		this.mentorNum = mentorNum;
		this.satisfaction = satisfaction; 
		this.participation = participation;
		this.preparation = preparation;
		
	}
	public Star (int mentorNum, int satisfaction, int participation, int preparation) {
		
		this.mentorNum = mentorNum;
		this.satisfaction = satisfaction; 
		this.participation = participation;
		this.preparation = preparation;
		
	}
	
	
	public int getRevNum() {
		return revNum;
	}
	public void setRevNum(int revNum) {
		this.revNum = revNum;
	}
	public int getMentorNum() {
		return mentorNum;
	}
	public void setMentorNum(int mentorNum) {
		this.mentorNum = mentorNum;
	}
	public int getSatisfaction() {
		return satisfaction;
	}
	public void setSatisfaction(int satisfaction) {
		this.satisfaction = satisfaction;
	}
	public int getParticipation() {
		return participation;
	}
	public void setParticipation(int participation) {
		this.participation = participation;
	}
	public int getPreparation() {
		return preparation;
	}
	public void setPreparation(int preparation) {
		this.preparation = preparation;
	}
	public float getStarTotal() {
		return starTotal;
	}
	public void setStarTotal(float starTotal) {
		this.starTotal = starTotal;
	}
	
	
}
