package model;

import java.util.Date;

public class TeamLarge {
   private int num;
   private String name;
   private int mentorNum;
   private String startDate;
   private int field1;
   private String meetingLoc;
   private int limit;
   private Field field;
   

   public TeamLarge() {   
   }
   
   public TeamLarge(int num, String name, int mentorNum, String startDate, int field1, String meetingLoc, int limit) {
      this.num = num;
      this.name = name;
      this.mentorNum = mentorNum;
      this.startDate = startDate;
      this.field1 = field1;
      this.meetingLoc = meetingLoc;
      this.limit = limit;
   }
   public TeamLarge(String name, int mentorNum, String startDate, int field1, String meetingLoc, int limit) {
	      this.name = name;
	      this.mentorNum = mentorNum;
	      this.startDate = startDate;
	      this.field1 = field1;
	      this.meetingLoc = meetingLoc;
	      this.limit = limit;
	   }
   public TeamLarge(String tname) {
	   field = new Field();
	   this.name = tname;
	   
	   
   }


   public int getNum() {
      return num;
   }

   public void setNum(int num) {
      this.num = num;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public String getStartDate() {
      return startDate;
   }

   public void setStartDate(String startDate) {
      this.startDate = startDate;
   }
   
   public int getField1() {
      return field1;
   }

   public void setField1(int field1) {
      this.field1 = field1;
   }

   public Field getField() {
      return field;
   }

   public void setField(Field field) {
      this.field = field;
   }
   
   public String getMeetingLoc() {
      return meetingLoc;
   }

   public void setMeetingLoc(String meetingLoc) {
      this.meetingLoc = meetingLoc;
   }

   public int getMentorNum() {
      return mentorNum;
   }
   public void setMentorNum(int mentorNum) {
      this.mentorNum = mentorNum;
   }
   
   public int getLimit() {
      return limit;
   }

   public void setLimit(int limit) {
      this.limit = limit;
   }
   
   
}