package model;

public class TeamLargeHis {
   private int teamNum;
   private int memberNum;
   
   public TeamLargeHis(int tnum, int mnum) {
      this.teamNum = tnum;
      this.memberNum = mnum;
   }
   public int getTeamNum() {
      return teamNum;
   }
   public void setTeamNum(int teamNum) {
      this.teamNum = teamNum;
   }
   public int getMemberNum() {
      return memberNum;
   }
   public void setMemberNum(int memberNum) {
      this.memberNum = memberNum;
   }
   
   
}