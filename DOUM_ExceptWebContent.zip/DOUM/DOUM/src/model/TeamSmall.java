package model;

import java.util.Date;

public class TeamSmall {
   private int num;
   private String name;
   private int mentorNum;
   private String startDate;
   private int field1;
   private String meetingLoc;
   //private Date endDate;
   private String endDate;
   private int support;
   private Field field;
   private Mentee mentee;
//   private int mentee1;
//   private int mentee2;
//   private int mentee3;
//   private int mentee4;

   
//   11.27 ���� �� (mentee1,2,3,4)
//   public TeamSmall(String name, Date startDate, int field, String meetingLoc, Date endDate,
//         int support, int mentee1, int mentee2, int mentee3, int mentee4, int mentorNum) {
//      this.name = name;
//      this.startDate = startDate;
//      this.field = field;
//      this.meetingLoc = meetingLoc;
//      this.endDate = endDate;
//      this.support = support;
//      this.mentee1 = mentee1;
//      this.mentee2 = mentee2;
//      this.mentee3 = mentee3;
//      this.mentee4 = mentee4;
//      this.mentorNum = mentorNum;
//   }


//   public TeamSmall(int tnum, String name, Date startDate, int field, String meetingLoc, Date endDate,
//         int support, int mentee1, int mentee2, int mentee3, int mentee4, int mentorNum) {
//      this(name,startDate,field,meetingLoc,endDate,support,mentee1,mentee2,mentee3,mentee4,mentorNum);
//      this.num = tnum;
//   }
   

   public TeamSmall() {} //�⺻������

   
   public TeamSmall(String name, String startDate, int field1, String meetingLoc, String endDate,//Date endDate,
   int support, int mentorNum) {
   this.name = name;
   this.startDate = startDate;
   this.field1 = field1;
   this.meetingLoc = meetingLoc;
   this.endDate = endDate;
   this.support = support;
   this.mentorNum = mentorNum;
   }
   public TeamSmall(String name, int field1, String meetingLoc, String endDate,//Date endDate,
		  int mentorNum) {
		   this.name = name;
		   this.field1 = field1;
		   this.meetingLoc = meetingLoc;
		   this.endDate = endDate;
	
		   this.mentorNum = mentorNum;
		   }
   
   public TeamSmall(int tnum, String name, String startDate, int field1, String meetingLoc, String endDate,//Date endDate,
         int support, int mentorNum) {
      this(name,startDate,field1,meetingLoc,endDate,support,mentorNum);
      this.num = tnum;
   }
   
   public TeamSmall(int tnum, String tname, int field1, String meetingloc, String endDate) {//Date date) {
      this.num = tnum;
      this.name = tname;
      this.field1 = field1;
      this.meetingLoc = meetingloc;
      this.endDate = endDate;
   }

   
   
   public TeamSmall(String tname) {
	   field = new Field();
	   this.name = tname;
	   
	   
   }

   public int getNum() {
      return num;
   }


   public void setNum(int num) {
      this.num = num;
   }


   public String getName() {
      return name;
   }


   public void setName(String name) {
      this.name = name;
   }


   public int getMentorNum() {
      return mentorNum;
   }


   public void setMentorNum(int mentorNum) {
      this.mentorNum = mentorNum;
   }


   public String getStartDate() {
      return startDate;
   }

   
   public void setStartDate(String startDate) {
      this.startDate = startDate;
   }
   public Field getField() {
	   return field;
	   
   }
   public void setField(Field field) {
	   
	   this.field = field;
	   
   }

   public int getField1() {
      return field1;
   }


   public void setField1(int field1) {
      this.field1 = field1;
   }


   public String getMeetingLoc() {
      return meetingLoc;
   }


   public void setMeetingLoc(String meetingLoc) {
      this.meetingLoc = meetingLoc;
   }


   /*public Date getEndDate() {
      return endDate;
   }
   public void setEndDate(Date endDate) {
      this.endDate = endDate;
   }*/
   
   public String getEndDate() {
      return endDate;
   }
   public void setEndDate(String endDate) {
      this.endDate = endDate;
   }
   public int getSupport() {
      return support;
   }
   public void setSupport(int support) {
      this.support = support;
   }
   
   public void setMentee(Mentee mentee) {
      this.mentee = mentee;
   }
   public Mentee getMentee() {
      return mentee;
   }
   
//   public int getMentee1() {
//      return mentee1;
//   }
//   public void setMentee1(int mentee1) {
//      this.mentee1 = mentee1;
//   }
//   public int getMentee2() {
//      return mentee2;
//   }
//   public void setMentee2(int mentee2) {
//      this.mentee2 = mentee2;
//   }
//   public int getMentee3() {
//      return mentee3;
//   }
//   public void setMentee3(int mentee3) {
//      this.mentee3 = mentee3;
//   }
//   public int getMentee4() {
//      return mentee4;
//   }
//   public void setMentee4(int mentee4) {
//      this.mentee4 = mentee4;
//   }
//   
   
   
}