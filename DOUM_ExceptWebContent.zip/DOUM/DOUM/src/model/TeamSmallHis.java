package model;

public class TeamSmallHis {
	private int teamNum;
	private int memberNum;
	
	public TeamSmallHis(int tnum, int mnum) {
		this.teamNum = tnum;
		this.memberNum = mnum;
	}
	public int getTeamNum() {
		return teamNum;
	}
	public void setTeamNum(int teamNum) {
		this.teamNum = teamNum;
	}
	public int getMemberNum() {
		return memberNum;
	}
	public void setMemberNum(int memberNum) {
		this.memberNum = memberNum;
	}
	
	
}
