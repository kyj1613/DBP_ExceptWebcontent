package model;

public class Waiting {
   private int waitnum;
   private String mname;
   private int mnum;
   private int tnum;
   private Waiting waiting;
   private Member member;
private TeamSmall teamSmall;
   
public Waiting() {}
   public Waiting(String mname, int mnum, int tnum) {
      this.mname = mname;
      this.mnum = mnum;
      this.tnum = tnum;
   }
   public Waiting(int waitnum, String mname) {
	   // TODO Auto-generated constructor stub
	   this.waitnum = waitnum;
	   this.mname = mname;
	}
   public Waiting(int waitnum,String mname, int mnum, int tnum) {
	   		this.mname = mname;
	      this.mnum = mnum;
	      this.tnum = tnum;
	      this.waitnum = waitnum;
	   }
   
   
   public int getWaitnum() {
      return waitnum;
   }

   public void setWaitnum(int waitnum) {
      this.waitnum = waitnum;
   }

   public String getMname() {
      return mname;
   }

   public void setMname(String mname) {
      this.mname = mname;
   }

   public int getMnum() {
      return mnum;
   }

   
   public void setMnum(int mnum) {
      this.mnum = mnum;
   }

   public int getTnum() {
      return tnum;
   }

   public void setTnum(int tnum) {
      this.tnum = tnum;
   }
   public Waiting getWaiting() {
		// TODO Auto-generated method stub
		 return waiting;
    }
   
   
   public void setWaiting(Waiting waiting) {
	// TODO Auto-generated method stub
	 this.waiting = waiting;
   }
   
   public Member getMember() {
		// TODO Auto-generated method stub
		 return member;
   }
   public void setMember(Member member) {
	// TODO Auto-generated method stub
	   this.member = member;
   }
   
   public TeamSmall getTeamSmall() {
	   return teamSmall;
   }
public void setTeamSmall(TeamSmall teamSmall) {
	// TODO Auto-generated method stub
		this.teamSmall = teamSmall;
}	


   
   
}