package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Location;
import model.RentHis;

public class LocationDAO {
	private JDBCUtil jdbcUtil = null;
	
	public LocationDAO() {
		jdbcUtil = new JDBCUtil();
	}
	
	public Location findLocationByName(String locname) throws SQLException{
		String sql = "SELECT roomnum, locnum, locname, address, city FROM location "
				+ "WHERE LOCNAME=? ";
		jdbcUtil.setSqlAndParameters(sql, new Object[] {locname});
		
		try {
			ResultSet rs = jdbcUtil.executeQuery();
			
			if (rs.next()) {
				Location loc = new Location(
						rs.getInt("roomnum"),
						rs.getInt("locnum"),
						rs.getString("locname"),
						rs.getString("address"),
						rs.getString("city"));
				return loc;
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.close();
		}
		return null;
	}
	public List<Location> findLocationList() {

	   String sql = "SELECT roomnum, locnum, locname, address, city "
			   			+ "FROM LOCATION ";
    
         jdbcUtil.setSqlAndParameters(sql,null);

         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<Location> LocationList = new ArrayList<Location>();
         
            while(rs.next()) {
              
               Location Location = new Location(
                     rs.getInt("roomnum"),        
                       rs.getInt("locnum"),            
                       rs.getString("locname"),
                       rs.getString("address"),
            		   rs.getString("city"));
           		
           		LocationList.add(Location);   
            }   
            return LocationList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
	
	public List<Location> findDistinctLocationList() {
    
	   String sql = "SELECT distinct locnum, locname " + 
	   		"FROM LOCATION order by locnum";
    
         jdbcUtil.setSqlAndParameters(sql,null);

         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<Location> LocationList = new ArrayList<Location>();
         
            while(rs.next()) {
          
               Location Location = new Location(
      
                       rs.getInt("locnum"),            
                       rs.getString("locname")
);
           		
           		LocationList.add(Location);   
            }   
            return LocationList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
	public Location findLocationByCity(String city) throws SQLException{
	      String sql = "SELECT roomnum, locnum, locname, address, city "
	            + "FROM location "
	            + "WHERE CITY=? ";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {city});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         
	         if (rs.next()) {
	            Location loc = new Location(
	                  rs.getInt("roomnum"),
	                  rs.getInt("locnum"),
	                  rs.getString("locname"),
	                  rs.getString("city"),
	                  rs.getString("address"));
	            return loc;
	         }
	      } catch (Exception ex) {
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.close();
	      }
	      return null;
	   }
	   
	   public Location findLocationByLoc(String locname) throws SQLException{
	      String sql = "SELECT roomnum, locnum, locname, city, address "
	            + "FROM location "
	            + "WHERE LOCNAME=? ";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {locname});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         
	         if (rs.next()) {
	            Location loc = new Location(
	                  rs.getInt("roomnum"),
	                  rs.getInt("locnum"),
	                  rs.getString("locname"),
	                  rs.getString("city"),
	                  rs.getString("address"));
	            return loc;
	         }
	      } catch (Exception ex) {
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.close();
	      }
	      return null;
	   }
	   public Location findLocationByLocNum(int locnum) throws SQLException{
		      String sql = "SELECT roomnum, locnum, locname, city, address "
		            + "FROM location "
		            + "WHERE LOCNUM=? ";
		      jdbcUtil.setSqlAndParameters(sql, new Object[] {locnum});
		      
		      try {
		         ResultSet rs = jdbcUtil.executeQuery();
		         
		         if (rs.next()) {
		            Location loc = new Location(
		                  rs.getInt("roomnum"),
		                  rs.getInt("locnum"),
		                  rs.getString("locname"),
		                  rs.getString("city"),
		                  rs.getString("address"));
		            return loc;
		         }
		      } catch (Exception ex) {
		         ex.printStackTrace();
		      } finally {
		         jdbcUtil.close();
		      }
		      return null;
		   }
	   public Location findLocationByLocRoom(int locnum, int roomnum) throws SQLException{
		      String sql = "SELECT roomnum, locnum, locname, city, address "
		            + "FROM location "
		            + "WHERE LOCNum=? and ROOMNUM=? ";
		      jdbcUtil.setSqlAndParameters(sql, new Object[] {locnum, roomnum});
		      
		      try {
		         ResultSet rs = jdbcUtil.executeQuery();
		         
		         if (rs.next()) {
		            Location loc = new Location(
		                  rs.getInt("roomnum"),
		                  rs.getInt("locnum"),
		                  rs.getString("locname"),
		                  rs.getString("city"),
		                  rs.getString("address"));
		            return loc;
		         }
		      } catch (Exception ex) {
		         ex.printStackTrace();
		      } finally {
		         jdbcUtil.close();
		      }
		      return null;
		   }

}
