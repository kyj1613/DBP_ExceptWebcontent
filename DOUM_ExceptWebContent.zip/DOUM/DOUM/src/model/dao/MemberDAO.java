package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Member;
import model.Mentor;


public class MemberDAO {
   private JDBCUtil jdbcUtil = null;
   
   public MemberDAO() {         
      jdbcUtil = new JDBCUtil();   // JDBCUtil ��ü ����
   }
      
   /**
    * ����� ���� ���̺��� ���ο� ����� ����.
    */
   public int create(Member member) throws SQLException {
      String sql = "INSERT INTO MEMBER (mnum, mid, mpassword, mname, msex, mnickname, mtel, mbirth, memail, field1, field2, field3) "
            + "VALUES (seq_mnum.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      Object[] param = new Object[] {member.getId(),member.getPassword(),member.getName(),member.getSex(),member.getNickname(),
                              member.getTel(),member.getBirth(),member.getEmail(), member.getField().get(0), member.getField().get(1),
                              member.getField().get(2)};            
      jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil �� insert���� �Ű� ���� ����
                  
      try {            
         int result = jdbcUtil.executeUpdate();   // insert �� ����
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      } finally {      
         jdbcUtil.commit();
         jdbcUtil.close();   // resource ��ȯ
      }      
      return 0;         
   }
   
   public int update(Member member) throws SQLException {
      String sql = "UPDATE MEMBER " + "SET MPASSWORD=?, MNICKNAME=?, MTEL=? "
            + "WHERE MID=?";
      Object[] param = new Object[] {member.getPassword(),
            member.getNickname(), member.getTel(), member.getId()};            
      jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
         
      try {            
         int result = jdbcUtil.executeUpdate();   // update �� ����
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      }
      finally {
         jdbcUtil.commit();
         jdbcUtil.close();   // resource ��ȯ
      }      
      return 0;
   }

   
   /**
    * �־��� ����� ID�� �ش��ϴ� ����� ������ �����ͺ��̽����� ã�� User ������ Ŭ������ 
    * �����Ͽ� ��ȯ.
    */
   public Member findMember(String id) throws SQLException {
        String sql = "SELECT MNUM, MPASSWORD, MNAME, MSEX, MNICKNAME, MTEL, MBIRTH,  MEMAIL, FIELD1, FIELD2, FIELD3 "
                 + "FROM MEMBER WHERE MID=? ";              
      jdbcUtil.setSqlAndParameters(sql, new Object[] {id});   // JDBCUtil�� query���� �Ű� ���� ����

      try {
         ResultSet rs = jdbcUtil.executeQuery();      // query ����
         if (rs.next()) {                  // �л� ���� �߰�
            List<Integer> field = new ArrayList<Integer>();
            field.add(rs.getInt("field1"));
            field.add(rs.getInt("field2"));
            field.add(rs.getInt("field3"));

            Member member = new Member(      // User ��ü�� �����Ͽ� �л� ������ ����
                  id,
               rs.getString("mpassword"),
               rs.getString("mname"),
               rs.getString("msex"),
               rs.getString("mnickname"),
               rs.getString("mtel"),
               rs.getString("mbirth"),
               rs.getString("memail"),
               field);
            member.setNum(rs.getInt("mnum"));
            
            return member;
         }
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.close();      // resource ��ȯ
      }
      return null;
   }
   
   
   public Member findMemberByName(String mname) throws SQLException {
       String sql = "SELECT MID, MNUM, MPASSWORD, MNAME, MSEX, MNICKNAME, MTEL, MBIRTH,  MEMAIL, FIELD1, FIELD2, FIELD3 "
                + "FROM MEMBER WHERE MNAME=? ";              
     jdbcUtil.setSqlAndParameters(sql, new Object[] {mname});   // JDBCUtil�� query���� �Ű� ���� ����

     try {
        ResultSet rs = jdbcUtil.executeQuery();      // query ����
        if (rs.next()) {                  // �л� ���� �߰�
           List<Integer> field = new ArrayList<Integer>();
           field.add(rs.getInt("field1"));
           field.add(rs.getInt("field2"));
           field.add(rs.getInt("field3"));

           Member member = new Member(      // User ��ü�� �����Ͽ� �л� ������ ����
                rs.getString("mid"),
                rs.getString("mpassword"),
                mname,
                rs.getString("msex"),
                rs.getString("mnickname"),
                rs.getString("mtel"),
                rs.getString("mbirth"),
                rs.getString("memail"),
                field);
             member.setNum(rs.getInt("mnum"));
           
           return member;
        }
     } catch (Exception ex) {
        ex.printStackTrace();
     } finally {
        jdbcUtil.close();      // resource ��ȯ
     }
     return null;
  }
   
   
   /**
    * �־��� ����� ID�� �ش��ϴ� ����ڰ� �����ϴ��� �˻� 
    */
   public boolean existingMember(String memberId) throws SQLException {
      String sql = "SELECT count(*) FROM MEMBER WHERE MID=?";      
      jdbcUtil.setSqlAndParameters(sql, new Object[] {memberId});   // JDBCUtil�� query���� �Ű� ���� ����

      try {
         ResultSet rs = jdbcUtil.executeQuery();      // query ����
         if (rs.next()) {
            int count = rs.getInt(1);
            return (count == 1 ? true : false);
         }
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.close();      // resource ��ȯ
      }
      return false;
   }
   
   /**
    * ȸ�� ���ɺоߺ� ���� ����Ʈ �˻�
    */
   public List<Mentor> recommendMentors(int fieldNum) throws Exception {
       String sql = "SELECT ROWNUM, MNUM, MID, MNAME, STAR, NVL(HISTORY, 0) as HISTORY "
                   + "FROM (SELECT M1.MNUM AS MNUM, M1.MID AS MID, M1.MNAME AS MNAME, STAR, HISTORY "
                        + "FROM MEMBER M1 JOIN (SELECT M.MNUM, M.MENTORNUM, STAR, HISTORY "
                                           + "FROM MENTOR M LEFT OUTER JOIN (SELECT MENTORNUM, COUNT(TNUM) AS HISTORY "
                                                                           + "FROM TEAM_SMALL "
                                                                           + "GROUP BY MENTORNUM) T "
                                                       + "ON M.MENTORNUM = T.MENTORNUM "
                                           + "WHERE M.FIELD = ?) M2 "
                                    + "ON M1.MNUM = M2.MNUM "
                        + "ORDER BY STAR DESC) "
                  + "WHERE ROWNUM <= 5";
          jdbcUtil.setSqlAndParameters(sql, new Object[] {fieldNum});      // JDBCUtil�� query�� ����
                   
          try {
             ResultSet rs = jdbcUtil.executeQuery();         // query ����         
             List<Mentor> mentorList = new ArrayList<Mentor>();   // User���� ����Ʈ ����
             while (rs.next()) {
                Mentor mentor = new Mentor();         // User ��ü�� �����Ͽ� ���� ���� ������ ����
                mentor.setStar(rs.getFloat("star"));
                mentor.setHistory(rs.getInt("history"));
                Member member = new Member();
                member.setNum(rs.getInt("mnum"));
                member.setId(rs.getString("mid"));
                member.setName(rs.getString("mname"));
                mentor.setMember(member);
        
                mentorList.add(mentor);            // List�� User ��ü ����
             }      
             return mentorList;               
             
          } catch (Exception ex) {
             ex.printStackTrace();
          } finally {
             jdbcUtil.close();      // resource ��ȯ
          }
          return null;   
    }
 
} 