package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.TeamSmall;
import model.Mentee;

public class MenteeDAO {
   private JDBCUtil jdbcUtil = null;
   
   public MenteeDAO() {         
      jdbcUtil = new JDBCUtil();   // JDBCUtil ��ü ����
   }
   
   public int create(Mentee mentee) throws SQLException{
      String sql = "INSERT INTO MENTEE (tnum, mnum) "
         + "VALUES(?,?)";
      Object[] param = new Object[] {mentee.getTnum(),mentee.getMnum()};
      jdbcUtil.setSqlAndParameters(sql,param);

      try {
         int result = jdbcUtil.executeUpdate();
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      } finally {
         jdbcUtil.commit();
         jdbcUtil.close();
      } 
      return 0;
   }
   
   public int remove(Mentee mentee) throws SQLException {
      String sql = "DELETE FROM MENTEE WHERE TNUM=? and MNUM=?";
         Object[] param = new Object[] {mentee.getTnum(),mentee.getMnum()};            
         jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
            
         try {            
            int result = jdbcUtil.executeUpdate();   // update �� ����
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         }
         finally {
            jdbcUtil.commit();
            jdbcUtil.close();   // resource ��ȯ
         }      
         return 0;
   }
   public int removeByTnum(Mentee mentee) throws SQLException {
	      String sql = "DELETE FROM MENTEE WHERE TNUM=? ";
	         Object[] param = new Object[] {mentee.getTnum()};            
	         jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
	            
	         try {            
	            int result = jdbcUtil.executeUpdate();   // update �� ����
	            return result;
	         } catch (Exception ex) {
	            jdbcUtil.rollback();
	            ex.printStackTrace();
	         }
	         finally {
	            jdbcUtil.commit();
	            jdbcUtil.close();   // resource ��ȯ
	         }      
	         return 0;
	   }
   
   
   public List<Mentee> findTnumByMnum(int mnum) throws SQLException{
	      String sql = "SELECT tnum FROM mentee where mnum =?";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {mnum});
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         List<Mentee> tnumList = new ArrayList<Mentee>();
	         while(rs.next()) {
	            Mentee mentee = new Mentee();
	            mentee.setTnum(rs.getInt("tnum"));
	            tnumList.add(mentee);
	         }
	         return tnumList;
	      } catch(Exception ex) {
	           ex.printStackTrace();
	        } finally {
	           jdbcUtil.close();
	        }
	        return null;
	   }
   public List<Mentee> findMenteeList() throws SQLException {
      String sql = "SELECT * "
            + "FROM MEMBER m JOIN MENTEE s "
            + "ON m.mnum = s.mnum"; 
      
         jdbcUtil.setSqlAndParameters(sql,null);

         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<Mentee> menteeList = new ArrayList<Mentee>();
            while(rs.next()) {
               Mentee mentee = new Mentee(
                     rs.getInt("tnum"),
                     rs.getInt("mnum"));
               mentee.getMember().setName(rs.getString("mname"));
               mentee.getMember().setId(rs.getString("mid"));
               mentee.getMember().setbirth(rs.getString("mbirth"));
               menteeList.add(mentee);   
            }   
            return menteeList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
   public List<Mentee> findMenteeList(int teamNum) throws SQLException {
       String sql = "SELECT * "
             + "FROM MEMBER m JOIN MENTEE s ON m.mnum = s.mnum "
             + "WHERE tnum=?"; 
       
          jdbcUtil.setSqlAndParameters(sql,new Object[] {teamNum});

          try {
             ResultSet rs = jdbcUtil.executeQuery();
             List<Mentee> menteeList = new ArrayList<Mentee>();
             while(rs.next()) {
                Mentee mentee = new Mentee(
                      rs.getInt("tnum"),
                      rs.getInt("mnum"));
                mentee.getMember().setName(rs.getString("mname"));
                mentee.getMember().setId(rs.getString("mid"));
                mentee.getMember().setbirth(rs.getString("mbirth"));
                menteeList.add(mentee);   
             }   
             return menteeList;
          } catch(Exception ex) {
             ex.printStackTrace();
          } finally {
             jdbcUtil.close();
          }
          return null;
    }
   
   
   
   /**
    * Ư�� ��small�� ���� ��Ƽ���� ���� count�Ͽ� ��ȯ
    */
   public int countMentee(int teamNum) {
      
      String sql = "SELECT COUNT(DECODE(tnum,?,1)) FROM MENTEE";
      jdbcUtil.setSqlAndParameters(sql, new Object[] {teamNum}); //jdbcUtil�� query���� �Ű����� ����
      
      try {
         ResultSet rs = jdbcUtil.executeQuery();
         if (rs.next()) {
            return rs.getInt(1);
         }
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.close();
      }
      return 0;
   }
}