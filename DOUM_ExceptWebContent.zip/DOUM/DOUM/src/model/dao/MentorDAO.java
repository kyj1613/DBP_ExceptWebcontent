package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.member.RegisterMemberController;
import model.Field;
import model.Member;
import model.Mentor;

public class MentorDAO{private static final Logger log = LoggerFactory.getLogger(MentorDAO.class);

   private JDBCUtil jdbcUtil = null;
   
   public MentorDAO(){
      jdbcUtil = new JDBCUtil();
   }

   //���ο� ���� ����
   public int create(Mentor mentor) throws SQLException { 
      String sql = "INSERT INTO MENTOR (mentornum, profile, mnum, field, star) "
         + "VALUES(seq_mentornum.nextval,?,?,?,?)";
      Object[] param = new Object[] {
            mentor.getProfile(), mentor.getMember().getNum(), 
            mentor.getField1(), 0};
      jdbcUtil.setSqlAndParameters(sql,param);

      try {
         int result = jdbcUtil.executeUpdate();
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      } finally {
         jdbcUtil.commit();
         jdbcUtil.close();
      } 
      return 0;
   }

   public int update(Mentor mentor) throws SQLException {
      String sql = "UPDATE MENTOR " + "SET profile=?, field=?, star=? "
               + "WHERE MENTORNUM=?";
         Object[] param = new Object[] {mentor.getProfile(), mentor.getField(), 
                mentor.getStar(), mentor.getNum()};            
         jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
            
         try {            
            int result = jdbcUtil.executeUpdate();   // update �� ����
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         }
         finally {
            jdbcUtil.commit();
            jdbcUtil.close();   // resource ��ȯ
         }      
         return 0;
   }
   public int updateStar(Mentor mentor) throws SQLException {
	      String sql = "UPDATE MENTOR " + "SET star=? "
	               + "WHERE MENTORNUM=?";
	         Object[] param = new Object[] {mentor.getStar(), mentor.getNum()};            
	         jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
	            
	         try {            
	            int result = jdbcUtil.executeUpdate();   // update �� ����
	            return result;
	         } catch (Exception ex) {
	            jdbcUtil.rollback();
	            ex.printStackTrace();
	         }
	         finally {
	            jdbcUtil.commit();
	            jdbcUtil.close();   // resource ��ȯ
	         }      
	         return 0;
	   }
   
   
   public Mentor findMentor(int mentorNum) throws SQLException {
         String sql = "SELECT mentornum, profile, m1.mnum, mid, mname, m1.field, star "
                   + "FROM MENTOR m1 JOIN MEMBER m2 ON m1.mnum = m2.mnum " 
               + "WHERE MENTORNUM=? ";          
                         
         jdbcUtil.setSqlAndParameters(sql, new Object[] {mentorNum});   // JDBCUtil�� query���� �Ű� ���� ����

         try {
              ResultSet rs = jdbcUtil.executeQuery();      // query ����
              if (rs.next()) {                  // �л� ���� �߰�
                 Mentor mentor = new Mentor(      // User ��ü�� �����Ͽ� �л� ������ ����
                       //mentorNum,
                    rs.getString("profile"),
                    rs.getInt("field"));
                 mentor.setStar(rs.getFloat("star"));
                 mentor.getMember().setNum(rs.getInt("mnum"));
                 mentor.getMember().setId(rs.getString("mid"));
                 mentor.getMember().setName(rs.getString("mname"));
                 return mentor;
              }
           } catch (Exception ex) {
              ex.printStackTrace();
           } finally {
              jdbcUtil.close();      // resource ��ȯ
           }
           return null;
      }
   		
   
   
   public Mentor findMentorById1(String id) throws SQLException {
       String sql = "SELECT mentornum, profile, m1.mnum, mid, mname, m1.field, star "
                 + "FROM MENTOR m1 JOIN MEMBER m2 ON m1.mnum = m2.mnum " 
             + "WHERE MID=? ";          
                       
       jdbcUtil.setSqlAndParameters(sql, new Object[] {id});   // JDBCUtil�� query���� �Ű� ���� ����

       try {
            ResultSet rs = jdbcUtil.executeQuery();      // query ����
            if (rs.next()) {                  // �л� ���� �߰�
               Mentor mentor = new Mentor(      // User ��ü�� �����Ͽ� �л� ������ ����
                
                  rs.getString("profile"),
                  rs.getInt("field"));
            
               mentor.setNum(rs.getInt("mentornum"));
               mentor.setStar(rs.getFloat("star"));
               mentor.getMember().setNum(rs.getInt("mnum"));
               mentor.getMember().setId(id);
               mentor.getMember().setName(rs.getString("mname"));
               return mentor;
            }
         } catch (Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();      // resource ��ȯ
         }
         return null;
    }
   
   
//      public Mentor findMentorById(String id) throws SQLException {
//         String sql = "SELECT mentornum, profile, m1.mnum, mid, mname, m1.field, m3.fieldname, star " + 
//         		"FROM MENTOR m1, MEMBER m2, field m3 " + 
//         		"where m1.mnum = m2.mnum and MID=? and m1.field = m3.fieldnum";          
//        
//         
//         
//         jdbcUtil.setSqlAndParameters(sql, new Object[] {id});   // JDBCUtil�� query���� �Ű� ���� ����
//
//         try {
//              ResultSet rs = jdbcUtil.executeQuery();      // query ����
//              if (rs.next()) {                  // �л� ���� �߰�
//                 Mentor mentor = new Mentor(      // User ��ü�� �����Ͽ� �л� ������ ����
//                       //mentorNum,
//                    rs.getString("profile"),
//                    rs.getInt("field"));
//                 mentor.getField().setFname(rs.getString("fieldname"));
//                 mentor.setNum(rs.getInt("mentornum"));
//                 mentor.setStar(rs.getFloat("star"));
//                 mentor.getMember().setNum(rs.getInt("mnum"));
//                 mentor.getMember().setId(id);
//                 mentor.getMember().setName(rs.getString("mname"));
//                 return mentor;
//              }
//           } catch (Exception ex) {
//              ex.printStackTrace();
//           } finally {
//              jdbcUtil.close();      // resource ��ȯ
//           }
//           return null;
//      }
//      
      
      public List<Mentor> findMentorList() throws SQLException {
          String sql = "SELECT mentornum, profile, m1.mnum, mid, mname, m1.field, m3.fieldname, star "
                + "FROM MENTOR m1, MEMBER m2, field m3 "
                + "WHERE m1.mnum = m2.mnum and m1.field = m3.fieldnum "
                + "ORDER BY mid";
          jdbcUtil.setSqlAndParameters(sql, null);      // JDBCUtil�� query�� ����
                   
          try {
             ResultSet rs = jdbcUtil.executeQuery();         // query ����         
             List<Mentor> mentorList = new ArrayList<Mentor>();   // Mentor���� ����Ʈ ����
             while (rs.next()) {
                Mentor mentor = new Mentor(         // Mentor ��ü�� �����Ͽ� ���� ���� ������ ����
                   rs.getInt("mentornum"),
                   rs.getString("profile"),
                   rs.getInt("field"), 
                   //rs.getString("fieldname"),
                   rs.getFloat("star"));
                
               mentor.getField().setFname(rs.getString("fieldname"));
                mentor.getMember().setNum(rs.getInt("mnum"));
                mentor.getMember().setId(rs.getString("mid"));
                mentor.getMember().setName(rs.getString("mname"));
                
                mentorList.add(mentor);            // List�� User ��ü ����
             }      
             return mentorList;               
             
          } catch (Exception ex) {
             ex.printStackTrace();
          } finally {
             jdbcUtil.close();      // resource ��ȯ
          }
          return null;   
       }
      
      /** 
       * field�� ���� ����Ʈ ���
       * radio��ư �Է��ҰŴϱ� int������ �� ����
       */
      //�����̸�, mid, �����ߴ�Ƚ��, ���� -> ������õ�� �ʿ�
      public List<Mentor> findByFieldMentorList(int checkfield) throws SQLException {
          String sql = "SELECT m2.mid, m2.mname, m2.memail, m3.fieldname, star " + 
          		"FROM MENTOR m1, MEMBER m2, FIELD m3 " + 
          		"WHERE m1.mnum=m2.mnum and m1.field = m3.fieldnum and m1.field=?";
          
          
          jdbcUtil.setSqlAndParameters(sql, new Object[] {checkfield}); //jdbcUtil�� query�� ����
          
          try {
             ResultSet rs = jdbcUtil.executeQuery();
             List<Mentor> mentorList = new ArrayList<Mentor>(); //�ش� mentor���� list����
             while(rs.next()) {
                         	 
            	Field field = new Field();
            	field.setFnum(checkfield);
            	field.setFname(rs.getString("fieldname"));
                Mentor mentor = new Mentor();
                Member member = new Member();
                
                member.setEmail(rs.getString("memail"));
                member.setId(rs.getString("mid"));
                member.setName(rs.getString("mname"));            
                mentor.setMember(member);
                mentor.setField(field);
                mentor.setStar(rs.getFloat("star"));
                mentorList.add(mentor);   //list�� mentor��ü ����
             }
             return mentorList;
          } catch (Exception ex) {
             ex.printStackTrace();
          } finally {
             jdbcUtil.close();
          }
          return null;
       }
     
  
}