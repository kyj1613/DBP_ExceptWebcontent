  package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.taglibs.standard.lang.jstl.parser.ParseException;

import model.*;

public class RentHisDAO {
	private JDBCUtil jdbcUtil = null;
	
	public RentHisDAO() {
		jdbcUtil = new JDBCUtil();
	}
	
	public int create(RentHis rentHis) throws SQLException{
		String sql = "INSERT INTO RENT_HIS (roomnum, locnum, tnum, rdate, rtime, rnum) "
				+ "VALUES(?, ?, ?, ?, ?, seq_rnum.nextval)";
		
		try {
			java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
	        java.util.Date utilDate = df.parse(rentHis.getRdate());
		
		Object[] param = new Object[] {rentHis.getRoomnum(), rentHis.getLocnum(), rentHis.getTnum(),
										new java.sql.Date(utilDate.getTime()), rentHis.getRtime()};
		jdbcUtil.setSqlAndParameters(sql, param);
		} catch (java.text.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try {
			int result = jdbcUtil.executeUpdate();
			return result;
		} catch(Exception ex) {
			ex.printStackTrace();
		} finally {
			jdbcUtil.commit();
			jdbcUtil.close();
		}
		return 0;
	}
	
	
	public int remove(RentHis rentHis) throws SQLException{
	      String sql = "DELETE FROM rent_his WHERE rnum=?";
	      
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {rentHis.getRnum()});
	      
	      try {
	         int result = jdbcUtil.executeUpdate();
	         return result;
	      } catch(Exception ex) {
	         ex.printStackTrace();
	         jdbcUtil.rollback();
	      } finally {
	         jdbcUtil.commit();
	         jdbcUtil.close();
	      }
	      return 0;
	   }
	public int removeTnum(RentHis rentHis) throws SQLException{
	      String sql = "DELETE FROM rent_his WHERE tnum=?";
	      
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {rentHis.getTnum()});
	      
	      try {
	         int result = jdbcUtil.executeUpdate();
	         return result;
	      } catch(Exception ex) {
	         ex.printStackTrace();
	         jdbcUtil.rollback();
	      } finally {
	         jdbcUtil.commit();
	         jdbcUtil.close();
	      }
	      return 0;
	   }
	
	

	public List<RentHis> findRentHisList() {
	   String sql = "SELECT roomnum, locnum, tnum, rdate, rtime, rnum "
			   			+ "FROM RENT_HIS";
      
         jdbcUtil.setSqlAndParameters(sql,null);

         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<RentHis> RentHisList = new ArrayList<RentHis>();
         
            while(rs.next()) {
               java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
               
               java.util.Date utilDate = new java.util.Date(rs.getDate("rdate").getTime());
               String dateString = df.format(utilDate);
               
               java.util.Date utilDate2 = new java.util.Date(rs.getDate("rtime").getTime());
               String dateString2 = df.format(utilDate2);
             
           		RentHis renthis = new RentHis(
                     rs.getInt("roomnum"),        
                       rs.getInt("locnum"),            
                       rs.getInt("tnum"),
                       dateString,
                       dateString2,
                       rs.getInt("rnum"));
           		
           		RentHisList.add(renthis);   
            }   
            return RentHisList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
	public List<RentHis> findRentHisList(String locname) throws SQLException {
	      String sql = "SELECT r.roomnum, r.locnum, tnum, rdate, rtime, rnum "
	             + "FROM location l, rent_his r "
	             + "WHERE l.locnum=r.locnum and l.roomnum=r.roomnum and l.locname=?";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {locname});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         List<RentHis> rentHisList = new ArrayList<RentHis>();
	         while(rs.next()) {
	            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
	            java.util.Date utilDate = new java.util.Date(rs.getDate("rdate").getTime());
	            String dateString = df.format(utilDate);
	            
	            RentHis rentHis = new RentHis(
	                  rs.getInt("roomnum"),
	                  rs.getInt("locnum"),
	                  rs.getInt("tnum"),
	                  rs.getString("rdate"),
	                  dateString,
	                  rs.getInt("rnum"));
	            rentHisList.add(rentHis);
	         }
	         return rentHisList;
	      } catch (Exception ex) {
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.close();
	      }
	      return null;
	   }
	public List<RentHis> findRentHisTnumList(int tnum) throws SQLException {
	      String sql = "SELECT roomnum, locnum, tnum, rdate, rtime, rnum "
	             + "FROM rent_his "
	             + "WHERE tnum=?";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {tnum});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         List<RentHis> rentHisList = new ArrayList<RentHis>();
	         while(rs.next()) {
	            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
	            java.util.Date utilDate = new java.util.Date(rs.getDate("rdate").getTime());
	            String dateString = df.format(utilDate);
	            
	            RentHis rentHis = new RentHis(
	                  rs.getInt("roomnum"),
	                  rs.getInt("locnum"),
	                  rs.getInt("tnum"),
	                  rs.getString("rdate"),
	                  dateString,
	                  rs.getInt("rnum"));
	            rentHisList.add(rentHis);
	         }
	         return rentHisList;
	      } catch (Exception ex) {
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.close();
	      }
	      return null;
	   }
	
	
	
	public List<RentHis> findRentHisLocnumRoomnumList(int locnum, int roomnum) throws SQLException {
        String sql = "SELECT r.roomnum, r.locnum, r.tnum, rdate, rtime, rnum, tname "
               + "FROM location l, rent_his r, team_small t "
               + "WHERE l.locnum=r.locnum and l.roomnum=r.roomnum and t.tnum = r.tnum and l.locnum=? and l.roomnum=? ORDER BY rdate,rtime";
        jdbcUtil.setSqlAndParameters(sql, new Object[] {locnum, roomnum});
        
        try {
           ResultSet rs = jdbcUtil.executeQuery();
           List<RentHis> rentHisList = new ArrayList<RentHis>();
           while(rs.next()) {

        	   java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
               java.util.Date utilDate = new java.util.Date(rs.getDate("rdate").getTime());
               String dateString = df.format(utilDate);
               
               TeamSmall teamSmall = new TeamSmall();
               teamSmall.setName(rs.getString("tname"));
            	
              RentHis rentHis = new RentHis(
                    rs.getInt("roomnum"),
                    rs.getInt("locnum"),
                    rs.getInt("tnum"),
                    dateString,
                    rs.getString("rtime"),
                    rs.getInt("rnum"));
              rentHis.setTeamSmall(teamSmall);
              rentHisList.add(rentHis);
           }
           return rentHisList;
        } catch (Exception ex) {
           ex.printStackTrace();
        } finally {
           jdbcUtil.close();
        }
        return null;
     }

//	public int countRentHis(RentHis rentHis) throws SQLException{
//	      String sql = "SELECT COUNT(tnum) FROM rent_his WHERE locnum=? AND roomnum=?";
//	      Object[] param = new Object[] {rentHis.getLocnum(),rentHis.getRoomnum()};
//	      jdbcUtil.setSqlAndParameters(sql, param);
//	      try {
//	         ResultSet rs = jdbcUtil.executeQuery();
//	         if (rs.next()) {
//	            return rs.getInt(1);
//	         }
//	      } catch(Exception ex) {
//	         ex.printStackTrace();
//	      } finally {
//	         jdbcUtil.close();
//	      }
//	      return 0;
//	   }

}
