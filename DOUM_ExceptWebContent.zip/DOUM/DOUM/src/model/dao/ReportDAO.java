package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import model.Report;
import model.Member;
import model.Mentee;
import model.TeamSmall;

public class ReportDAO {
   private JDBCUtil jdbcUtil = null;
      
   public ReportDAO() {         
      jdbcUtil = new JDBCUtil();   // JDBCUtil ��ü ����
   }
   
   public int create(Report report) throws SQLException {
         String sql = "INSERT INTO REPORT (rptnum, tnum, url, rptupdate, url_rcp) "
               + "VALUES (seq_rptnum.nextval, ?, ?, SYSDATE, ?)";
                    
         try { 
        	 
            Object[] param = new Object[] {report.getTnum(), report.getUrl(), report.getUrl_rcp()};            
            jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil �� insert���� �Ű� ���� ����
         
         } catch(Exception e) {
          // TODO Auto-generated catch block
              e.printStackTrace();
          }
         
         try {
            int result = jdbcUtil.executeUpdate();   // insert �� ����
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         } finally {      
            jdbcUtil.commit();
            jdbcUtil.close();   // resource ��ȯ
         }      
         return 0;         
   }
   
   public int update(Report report) throws SQLException {
         String sql = "UPDATE REPORT " + "SET url=?, rptupdate=?, url_rcp=? "
               + "WHERE RPTNUM=?"; 
         
         try { 
            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
            java.util.Date utilDate = df.parse(report.getRptUpdate());
            
            Object[] param = new Object[] {report.getUrl(),
                  report.getRptUpdate(), report.getUrl_rcp(), report.getRptnum()};            
            jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
            
         } catch(ParseException e) {
          // TODO Auto-generated catch block
              e.printStackTrace();
          }
         
         try {            
            int result = jdbcUtil.executeUpdate();   // update �� ����
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         }
         finally {
            jdbcUtil.commit();
            jdbcUtil.close();   // resource ��ȯ
         }      
         return 0;
   }
   
   public int remove(int rptNum) throws SQLException {
         String sql = "DELETE FROM REPORT WHERE RPTNUM=?";
            Object[] param = new Object[] {rptNum};            
            jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
               
            try {            
               int result = jdbcUtil.executeUpdate();   // update �� ����
               return result;
            } catch (Exception ex) {
               jdbcUtil.rollback();
               ex.printStackTrace();
            }
            finally {
               jdbcUtil.commit();
               jdbcUtil.close();   // resource ��ȯ
            }      
            return 0;
   }
   public int removeTnum(Report report) throws SQLException {
       String sql = "DELETE FROM REPORT WHERE tnum=?";
          Object[] param = new Object[] {report.getTnum()};            
          jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
             
          try {            
             int result = jdbcUtil.executeUpdate();   // update �� ����
             return result;
          } catch (Exception ex) {
             jdbcUtil.rollback();
             ex.printStackTrace();
          }
          finally {
             jdbcUtil.commit();
             jdbcUtil.close();   // resource ��ȯ
          }      
          return 0;
 }
   
//   public Report findReport(String month) throws SQLException {
//      String sql = "SELECT * " + 
//               "FROM REPORT " + 
//               "WHERE substr(to_char(rptupdat, 'YY/MM/DD'), 4, 2)=?";           
//      jdbcUtil.setSqlAndParameters(sql, new Object[] {month});   // JDBCUtil�� query���� �Ű� ���� ����
//   
//       try {
//          ResultSet rs = jdbcUtil.executeQuery();      // query ����
//           
//          if (rs.next()) {                  // �л� ���� �߰�
//             java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
//               java.util.Date utilDate = new java.util.Date(rs.getDate("rptupdate").getTime());
//               String dateString = df.format(utilDate);
//                 
//               Report report = new Report(
//                     rs.getInt("tnum"),
//                       rs.getString("url"),
//                       dateString,
//                       rs.getString("url_rcp"));
//               return report;
//          }
//          
//       } catch (Exception ex) {
//          ex.printStackTrace();
//       } finally {
//          jdbcUtil.close();      // resource ��ȯ
//       }
//       return null;
//   }
   
   public List<Report> findReportList(int tnum) throws SQLException {
         String sql = "SELECT * FROM REPORT WHERE tnum=?";
             Object[] param = new Object[] {tnum};  
            jdbcUtil.setSqlAndParameters(sql, param);
          
            try {
               ResultSet rs = jdbcUtil.executeQuery();
               List<Report> rList = new ArrayList<Report>();
            
               while(rs.next()) {
                  java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
                  java.util.Date utilDate = new java.util.Date(rs.getDate("rptupdate").getTime());
                  String dateString = df.format(utilDate);
               
               
                     Report r = new Report(
                           rs.getInt("tnum"),
                           rs.getString("url"),
                           dateString,
                           rs.getString("url_rcp"));
                     r.setRptnum(rs.getInt("rptnum"));
          
                     rList.add(r);   
                  }   
                  return rList;
                  
            } catch(Exception ex) {
               ex.printStackTrace();
            } finally {
               jdbcUtil.close();
            }
            return null;
      }
 
}