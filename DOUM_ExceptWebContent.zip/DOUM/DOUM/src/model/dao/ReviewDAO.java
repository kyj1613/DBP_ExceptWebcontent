package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Member;
import model.Mentor;
import model.Review;
import model.Star;
import model.TeamSmall;

public class ReviewDAO {

   private JDBCUtil jdbcUtil = null;
   
   public ReviewDAO() {
      jdbcUtil = new JDBCUtil();
   }
   
   /**
    * �ı�Խ��� �� �ۼ�
    */
   public int create(Review review) throws SQLException{
      String sql = "INSERT INTO REVIEW (revnum, mnum, mentornum, revtitle, revcontent, revdate, cnt) "
               + "VALUES(seq_revnum.nextval, ?, ?, ?, ?, ?, ?)";
      
      Object[] param = new Object[] {review.getMembernum(), review.getMentornum(), review.getRevtitle(), review.getRevcontent(), review.getRevdate(), review.getCnt()};
      
      jdbcUtil.setSqlAndParameters(sql, param);
      
      try {
         int result = jdbcUtil.executeUpdate();
         return result;
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.commit();
         jdbcUtil.close();
      }
      return 0;
   }
   
   public Review findReviewTitle(String revtitle) throws SQLException{
	      String sql = "SELECT * FROM REVIEW WHERE revtitle=?";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {revtitle});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         if (rs.next()) {
	            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
	            java.util.Date utilDate = new java.util.Date(rs.getDate("revdate").getTime());
	            String dateString = df.format(utilDate);
	            
	            Review review = new Review(
	                  rs.getInt("revnum"),
	                  rs.getInt("mnum"),
	                  rs.getInt("mentornum"),
	                  rs.getString("revtitle"),
	                  rs.getString("revcontent"),
	                  dateString,
	                  rs.getInt("cnt"));
	            return review;
	         }
	      } catch (Exception ex) {
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.close();
	      }   
	      return null;
	   }
   
   /**
    * 
    */
   public Review findReviewTitleMnum(int revnum) throws SQLException{
	      String sql = "SELECT revnum, review.mnum, mentornum, revtitle, revcontent, revdate, cnt, mname, mid " 
	    		  		+ "FROM REVIEW, member WHERE review.mnum = member.mnum and revnum=?";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {revnum});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         if (rs.next()) {
	            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
	            java.util.Date utilDate = new java.util.Date(rs.getDate("revdate").getTime());
	            String dateString = df.format(utilDate);
	            
	            Member member = new Member();
	            member.setName(rs.getString("mname"));
	            member.setId(rs.getString("mid"));
	            Review review = new Review(
	                  rs.getInt("revnum"),
	                  rs.getInt("mnum"),
	                  rs.getInt("mentornum"),
	                  rs.getString("revtitle"),
	                  rs.getString("revcontent"),
	                  dateString,
	                  rs.getInt("cnt"));
	            review.setMember(member);
	            return review;
	         }
	      } catch (Exception ex) {
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.close();
	      }   
	      return null;
	   }
   
   /**
    * ���� ����
    */
   public Review findReviewTitleStarMnum(int revnum) throws SQLException{
		      String sql = "SELECT review.revnum, mnum, review.mentornum, revtitle, revcontent, revdate, cnt, satisfaction, participation, preparation, starTotal "
	    		  		+ "FROM REVIEW, star WHERE review.revnum = star.revnum and review.revnum=?";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {revnum});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         if (rs.next()) {
	            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
	            java.util.Date utilDate = new java.util.Date(rs.getDate("revdate").getTime());
	            String dateString = df.format(utilDate);
	            
	            Star star = new Star();
	            star.setSatisfaction(rs.getInt("satisfaction"));
	            star.setParticipation(rs.getInt("participation"));
	            star.setPreparation(rs.getInt("preparation"));
	            star.setStarTotal(rs.getFloat("starTotal"));
	            Review review = new Review(
	                  rs.getInt("revnum"),
	                  rs.getInt("mnum"),
	                  rs.getInt("mentornum"),
	                  rs.getString("revtitle"),
	                  rs.getString("revcontent"),
	                  dateString,
	                  rs.getInt("cnt"));
	            review.setStar(star);
	            return review;
	         }
	      } catch (Exception ex) {
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.close();
	      }   
	      return null;
	   }
   

   /**
    * ���� ���
    */
   public List<Review> findReviewList(){
      String sql = "SELECT revnum, review.mnum, mentornum, revtitle, revcontent, revdate, cnt, mname "
    		 + "FROM review, member where review.mnum = member.mnum ORDER BY revnum";
      
      jdbcUtil.setSqlAndParameters(sql,null); 
      
      try {
         ResultSet rs = jdbcUtil.executeQuery();
         List<Review> reviewList = new ArrayList<Review>();
         
         while (rs.next()) {
            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
            java.util.Date utilDate = new java.util.Date(rs.getDate("revdate").getTime());
            String dateString = df.format(utilDate);
            
            Member member = new Member();
            member.setName(rs.getString("mname"));
            Review rev = new Review(
                        rs.getInt("revnum"),
                        rs.getInt("mnum"),
                        rs.getInt("mentornum"),
                        rs.getString("revtitle"),
                        rs.getString("revcontent"),
                        dateString,
                        rs.getInt("cnt"));
            
            rev.setMember(member);
            reviewList.add(rev);
         }
         return reviewList;
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.close();
      }
      return null;
   }
   
   /**
    * ��ȸ�� ����
    */
   public int upHit(int revnum) throws SQLException{
       String sql = "UPDATE review SET cnt=cnt+1 WHERE revnum=?";
       
       jdbcUtil.setSqlAndParameters(sql, new Object[] {revnum});
       try {
          int result = jdbcUtil.executeUpdate();
           return result;
        } catch (Exception ex) {
           jdbcUtil.rollback();
           ex.printStackTrace();
        }
        finally {
           jdbcUtil.commit();
           jdbcUtil.close();   // resource ��ȯ
        }      
        return 0;
     }


}