package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Star;

public class StarDAO {
	private JDBCUtil jdbcUtil = null;
	
	public StarDAO(){
		jdbcUtil = new JDBCUtil();
	}
	
	public int create(Star star) throws SQLException{
	      String sql = "INSERT INTO STAR (mentornum, satisfaction, participation, preparation, startotal, revnum) "
	            + "VALUES (?,?,?,?,?,seq_revnum.currval)";
	      
	      int satis = star.getSatisfaction();
	      int parti = star.getParticipation();
	      int prepa = star.getPreparation();
	      
	      star.setStarTotal((float)(satis + parti + prepa) / 3);
	      
	      Object[] param = new Object[] {star.getMentorNum(), star.getSatisfaction(), star.getParticipation(), star.getPreparation(), star.getStarTotal()};
	      jdbcUtil.setSqlAndParameters(sql, param);
	      
	      try {
	         int result = jdbcUtil.executeUpdate();
	         return result;
	      } catch(Exception ex) {
	         jdbcUtil.rollback();
	         ex.printStackTrace();
	      } finally {
	         jdbcUtil.commit();
	         jdbcUtil.close();
	      }
	      return 0;
	   }
	
	public int update(Star star) throws SQLException {
		return 0;
	}
	
	public int remove(int revNum) throws SQLException {
	      String sql = "DELETE FROM STAR WHERE REVNUM=?";
	        Object[] param = new Object[] {revNum};            
	        jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
	           
	        try {            
	           int result = jdbcUtil.executeUpdate();   // update �� ����
	           return result;
	        } catch (Exception ex) {
	           jdbcUtil.rollback();
	           ex.printStackTrace();
	        }
	        finally {
	           jdbcUtil.commit();
	           jdbcUtil.close();   // resource ��ȯ
	        }      
	        return 0;
	   }
	
	public List<Star> findStarListOfMentor(int mentorNum) throws SQLException {
	     
	      String sql = "SELECT * " 
	               + "FROM STAR "
	               + "WHERE MENTORNUM=?";
	      
	            Object[] param = new Object[] {mentorNum};  
	            jdbcUtil.setSqlAndParameters(sql, param);

	            try {
	               ResultSet rs = jdbcUtil.executeQuery();
	               List<Star> starList = new ArrayList<Star>();
	            
	               while(rs.next()) {
	                     Star star = new Star(
	                           rs.getInt("revnum"),
	                           rs.getInt("mentornum"),
	                           rs.getInt("satisfaction"),
	                           rs.getInt("participation"),
	                           rs.getInt("preparation"),
	                           rs.getFloat("starTotal"));
	                     starList.add(star);   
	                  }   
	               return starList;
	                  
	            } catch(Exception ex) {
	               ex.printStackTrace();
	            } finally {
	               jdbcUtil.close();
	            }
	            return null;
	      }

	
	public float sumOfStar(int mentorNum) throws SQLException {
		String sql = "SELECT SUM(starTotal) AS SUM " 
	            + "FROM STAR, MENTOR "
	            + "WHERE STAR.MENTORNUM = MENTOR.MENTORNUM AND STAR.MENTORNUM=?";
	   
	         Object[] param = new Object[] {mentorNum};  
	         jdbcUtil.setSqlAndParameters(sql, param);

	         try {
	            ResultSet rs = jdbcUtil.executeQuery();
	            if (rs.next()) {
	                return rs.getInt(1);
	            }   
	         } catch(Exception ex) {
	            ex.printStackTrace();
	         } finally {
	            jdbcUtil.close();
	         }
	         return 0;

	}
}
