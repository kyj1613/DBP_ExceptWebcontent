package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import model.Field;
import model.Mentee;
import model.TeamLarge;
import model.TeamSmall;

public class TeamLargeDAO {
   private JDBCUtil jdbcUtil = null;
      
      public TeamLargeDAO(){
         jdbcUtil = new JDBCUtil();
      }

      
      //���ο� �� ����
      public int create(TeamLarge teamLarge) throws SQLException {    
         String sql = "INSERT INTO TEAM_LARGE (tnum, tname, start_date, field, meeting_loc, mentornum, limit) "
            + "VALUES(seq_tlnum.nextval,?,?,?,?,?,?)";
         
         
         try {
            java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
            java.util.Date utilDate = df.parse(teamLarge.getStartDate());
            
            Object[] param = new Object[] {teamLarge.getName(), new java.sql.Date(utilDate.getTime()), 
                  teamLarge.getField1(), teamLarge.getMeetingLoc(), teamLarge.getMentorNum(), teamLarge.getLimit()};
            
            jdbcUtil.setSqlAndParameters(sql, param);

         }catch (ParseException e) {
           // TODO Auto-generated catch block
              e.printStackTrace();
          }
         
         try {
            int result = jdbcUtil.executeUpdate();
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         } finally {
            jdbcUtil.commit();
            jdbcUtil.close();
         } 
         return 0;
      }

      public int update(TeamLarge teamLarge) throws SQLException {   
         String sql = "UPDATE TEAM_LARGE " + "SET start_date=?, meeting_loc=? "
                  + "WHERE TNUM=?";
            Object[] param = new Object[] {teamLarge.getStartDate(), teamLarge.getMeetingLoc(), teamLarge.getNum()};            
            jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
               
            try {            
               int result = jdbcUtil.executeUpdate();   // update �� ����
               return result;
            } catch (Exception ex) {
               jdbcUtil.rollback();
               ex.printStackTrace();
            }
            finally {
               jdbcUtil.commit();
               jdbcUtil.close();   // resource ��ȯ
            }      
            return 0;
      }
      
      public int remove(int teamNum) throws SQLException {
         String sql = "DELETE FROM TEAM_LARGE WHERE TNUM=?";
            Object[] param = new Object[] {teamNum};            
            jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
               
            try {            
               int result = jdbcUtil.executeUpdate();   // update �� ����
               return result;
            } catch (Exception ex) {
               jdbcUtil.rollback();
               ex.printStackTrace();
            }
            finally {
               jdbcUtil.commit();
               jdbcUtil.close();   // resource ��ȯ
            }      
            return 0;
      }
      
      /**
       * tnum�� �ش��ϴ� tl list ���� ���
       */

      public List<TeamLarge> findTeamLargeList(int tNum) throws SQLException {
            String sql = "SELECT t.tnum, t.tname, f.fieldname, t.meeting_loc, t.mnum, t.limit " + 
                  "FROM (SELECT m.tnum, tl.tname, tl.field, tl.meeting_loc, m.mnum " + 
                  "        FROM (TEAM_LARGE tl JOIN MENTEE m " + 
                  "        ON tl.tnum = m.tnum )) t RIGHT OUTER JOIN Field f " + 
                  "                                ON t.field = f.fieldnum " + 
                  "WHERE t.tnum=?";
            
                Object[] param = new Object[] {tNum};  
               jdbcUtil.setSqlAndParameters(sql, param);
               
               try {
                  ResultSet rs = jdbcUtil.executeQuery();
                  List<TeamLarge> tlList = new ArrayList<TeamLarge>();
               
                  while(rs.next()) {
                     java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
                     java.util.Date utilDate = new java.util.Date(rs.getDate("start_date").getTime());
                     String dateString = df.format(utilDate);
                     Mentee mentee = new Mentee();
                     mentee.setMnum(rs.getInt("mnum"));
                  
                     TeamLarge tl = new TeamLarge(
                              rs.getInt("tnum"),
                              rs.getString("tname"),
                              rs.getInt("mentornum"),
                              dateString,
                              rs.getInt("field"),
                              rs.getString("meeting_loc"),
                              rs.getInt("limit"));
                           // ts.setMentee(mentee);
                           tlList.add(tl);   
                     }   
                     return tlList;
                     
               } catch(Exception ex) {
                  ex.printStackTrace();
               } finally {
                  jdbcUtil.close();
               }
               return null;
         }
      
      /**
       * TNUM PK�� ���� TEAM_Largeã��
       */
      public TeamLarge findTeamLarge(int tNum) throws SQLException {
         String sql = "SELECT tnum, tname, start_date, field, meeting_loc, mentornum, limit "
             + "FROM TEAM_LARGE "
               + "WHERE TNUM=? ";         
                         
         jdbcUtil.setSqlAndParameters(sql, new Object[] {tNum});   // JDBCUtil�� query���� �Ű� ���� ����

         try {
              ResultSet rs = jdbcUtil.executeQuery();      // query ����
              
              if (rs.next()) {          
                 java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
                 java.util.Date utilDate = new java.util.Date(rs.getDate("start_date").getTime());
                 String dateString = df.format(utilDate);    
                 
                 TeamLarge teamL = new TeamLarge(
                          rs.getInt("tnum"),
                           rs.getString("tname"),
                           rs.getInt("mentornum"),
                           dateString,
                           rs.getInt("field"),
                           rs.getString("meeting_loc"),
                           rs.getInt("limit"));
                 return teamL;
              }
           } catch (Exception ex) {
              ex.printStackTrace();
           } finally {
              jdbcUtil.close();      // resource ��ȯ
           }
           return null;
      }
      
      /**
       * TNAME�� ���� TEAM_LARGEã��
       */
      public TeamLarge findTeamLargeByName(String name) throws SQLException {
            String sql = "SELECT tnum, tname, start_date, field, meeting_loc, mentornum, limit "
                + "FROM TEAM_LARGE "
                  + "WHERE TNAME=? ";         
                            
            jdbcUtil.setSqlAndParameters(sql, new Object[] {name});   // JDBCUtil�� query���� �Ű� ���� ����

            try {
            	
                 ResultSet rs = jdbcUtil.executeQuery();      // query ����   
                 
                 if (rs.next()) {    
                    java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
                    java.util.Date utilDate = new java.util.Date(rs.getDate("start_date").getTime());
                    String dateString = df.format(utilDate);          
                    
                    
                    TeamLarge teamL = new TeamLarge(
                          rs.getInt("tnum"),
                              rs.getString("tname"),
                              rs.getInt("mentornum"),
                              dateString,
                              rs.getInt("field"),
                              rs.getString("meeting_loc"),
                              rs.getInt("limit"));
                    return teamL;
                 }
              } catch (Exception ex) {
                 ex.printStackTrace();
              } finally {
                 jdbcUtil.close();      // resource ��ȯ
              }
              return null;
         }
      public List<TeamLarge> findLargeTnameMentorByMnum(int mnum) throws SQLException{
	      String sql = "SELECT team_large.tname FROM team_large, mentor, member " + 
	      		"WHERE member.mnum=? and team_large.mentornum = mentor.mentornum and mentor.mnum = member.mnum";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {mnum});
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         List<TeamLarge> tlist = new ArrayList<TeamLarge>();
	         
	         while(rs.next()) {
	        	 TeamLarge ts = new TeamLarge();
	            ts.setName(rs.getString("tname"));
	            tlist.add(ts);
	         }
	         return tlist;
	      } catch(Exception ex) {
	           ex.printStackTrace();
	        } finally {
	           jdbcUtil.close();
	        }
	        return null;
	   }
      
      
      
      
      public String findTeamLargeFieldByName(String name) throws SQLException {
      
         String sql = "SELECT fieldname "
                     + "FROM TEAM_LARGE, FIELD "
                     + "WHERE TNAME=? and TEAM_LARGE.field = field.fieldnum";              
        
            jdbcUtil.setSqlAndParameters(sql, new Object[] {name});   // JDBCUtil�� query���� �Ű� ���� ����

            try {
                 ResultSet rs = jdbcUtil.executeQuery();      // query ����   
                 
                 if (rs.next()) {    

                    
                     String fieldname = rs.getString("fieldname");
                    return fieldname;
                 }
              } catch (Exception ex) {
                 ex.printStackTrace();
              } finally {
                 jdbcUtil.close();      // resource ��ȯ
              }
              return null;
         }
      
      
      /**
       * TEAM_LARGE list ��ȯ
       */
      public List<TeamLarge> findTeamLargeList() {
    	  
         String sql = "SELECT tnum, tname, start_date, t.field, f.fieldname, meeting_loc, mentornum, limit "
                        + "FROM TEAM_LARGE t, FIELD f "
                        + "WHERE t.field = f.fieldnum ORDER BY TNUM";
         
         
            jdbcUtil.setSqlAndParameters(sql,null);

            try {
               ResultSet rs = jdbcUtil.executeQuery();
               List<TeamLarge> teamList = new ArrayList<TeamLarge>();
            
               while(rs.next()) {
                  java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
                  
                  java.util.Date utilDate = new java.util.Date(rs.getDate("start_date").getTime());
                  String dateString = df.format(utilDate);
                
                     Field field = new Field();
                    field.setFname(rs.getString("fieldname"));
                    
                    TeamLarge teamL = new TeamLarge(
                          rs.getInt("tnum"),
                           rs.getString("tname"),
                           rs.getInt("mentornum"),
                           dateString,
                           rs.getInt("field"),
                           rs.getString("meeting_loc"),
                           rs.getInt("limit"));
                  teamL.setField(field);
                  teamList.add(teamL);   
               }   
               return teamList;
            } catch(Exception ex) {
               ex.printStackTrace();
            } finally {
               jdbcUtil.close();
            }
            return null;
      }
      
      /**
       * (Ȱ��)�оߺ� TEAM_LARGE����Ʈ ��������
       */
      public List<TeamLarge> findByFieldTeamLargeList(int field) throws SQLException {
         String sql = "SELECT tnum, tname, start_date, field, meeting_loc, mentornum, limit "
               + "FROM TEAM_LARGE " 
               + "WHERE FIELD=? "
               + "ORDER BY TNUM"; 
            
            jdbcUtil.setSqlAndParameters(sql, new Object[] {field});

            try {
               ResultSet rs = jdbcUtil.executeQuery();
               List<TeamLarge> teamList = new ArrayList<TeamLarge>();
          
               while(rs.next()) {
            	   
                  java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd"); 
                  java.util.Date utilDate = new java.util.Date(rs.getDate("start_date").getTime());
                  String dateString = df.format(utilDate);
                  
                  TeamLarge teamL = new TeamLarge(
                           rs.getInt("tnum"),
                           rs.getString("tname"),
                           rs.getInt("mentornum"),
                           dateString,
                           rs.getInt("field"),
                           rs.getString("meeting_loc"),
                           rs.getInt("limit"));
                  teamList.add(teamL);   
               }   
               return teamList;
            } catch(Exception ex) {
               ex.printStackTrace();
            } finally {
               jdbcUtil.close();
            }
            return null;
      }
      
      /**
       * ��Ƽ�� �����ߴ� ��� �˻��ϱ� ����
       */
      public List<TeamLarge> findTnameByMnum(int mnum) throws SQLException{
            String sql = "SELECT TEAM_LARGE.tname, limit, TEAM_LARGE.mentornum, team_large.tnum " + 
            		"FROM TEAM_LARGE, team_large_his, MEMBER " + 
            		"WHERE MEMBER.mnum=? and TEAM_LARGE.tnum = team_large_his.tnum and team_large_his.mnum = MEMBER.mnum";  
            jdbcUtil.setSqlAndParameters(sql,new Object[] {mnum});
            
            try {
               ResultSet rs = jdbcUtil.executeQuery();
               List<TeamLarge> teamList = new ArrayList<TeamLarge>();
               
               while(rs.next()) {
                  TeamLarge tl = new TeamLarge();
                  tl.setName(rs.getString("tname"));
                  tl.setNum(rs.getInt("tnum"));
                  tl.setMentorNum(rs.getInt("mentornum"));
                  teamList.add(tl);
               }
               return teamList;
            } catch(Exception ex) {
                 ex.printStackTrace();
              } finally {
                 jdbcUtil.close();
              }
              return null;
         }
      
      /**
       * ����� �����ߴ� ������ ����ϱ� ����
       */
      public List<TeamLarge> findTnameMentorByMnum(int mentornum) throws SQLException{
            String sql = "SELECT TEAM_LARGE.tname, limit " + 
            		"FROM TEAM_LARGE, MENTOR, MEMBER " + 
            		"WHERE TEAM_LARGE.mentornum=? and TEAM_LARGE.mentornum = MENTOR.mentornum and MENTOR.mnum = MEMBER.mnum";
            
            jdbcUtil.setSqlAndParameters(sql, new Object[] {mentornum});
            
            try {
               ResultSet rs = jdbcUtil.executeQuery();
               List<TeamLarge> teamList = new ArrayList<TeamLarge>();
               
               while(rs.next()) {
                  TeamLarge tl = new TeamLarge();
                  tl.setName(rs.getString("tname"));
                  
                  teamList.add(tl);
               }
               return teamList;
            } catch(Exception ex) {
                 ex.printStackTrace();
              } finally {
                 jdbcUtil.close();
              }
              return null;
         }
      
      public boolean existingTeamLarge(String teamName) throws SQLException {
         String sql = "SELECT count(*) " 
               + "FROM TEAM_LARGE " 
               + "WHERE tname=?";      
         jdbcUtil.setSqlAndParameters(sql, new Object[] {teamName});   // JDBCUtil�� query���� �Ű� ���� ����

         try {
            ResultSet rs = jdbcUtil.executeQuery();      // query ����
            if (rs.next()) {
               int count = rs.getInt(1);
               return (count == 1 ? true : false);
            }
         } catch (Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();      // resource ��ȯ
         }
         return false;
      }
}