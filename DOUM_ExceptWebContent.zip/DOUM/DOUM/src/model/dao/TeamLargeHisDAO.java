package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.TeamLarge;
import model.TeamLargeHis;
import model.service.ExistingTeamException;

public class TeamLargeHisDAO {
   private JDBCUtil jdbcUtil = null;
   
   public TeamLargeHisDAO() {         
      jdbcUtil = new JDBCUtil();   // JDBCUtil ��ü ����
   }
   
   public int create(TeamLargeHis TLHistory) throws SQLException, ExistingTeamException {
      String sql = "INSERT INTO TEAM_LARGE_HIS (tnum, mnum) "
         + "VALUES(?,?)";
      Object[] param = new Object[] {TLHistory.getTeamNum(), TLHistory.getMemberNum()};
      jdbcUtil.setSqlAndParameters(sql,param);

      try {
         int result = jdbcUtil.executeUpdate();
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      } finally {
         jdbcUtil.commit();
         jdbcUtil.close();
      } 
      return 0;
   }
   
   public int remove(TeamLargeHis TLHistory) throws SQLException {
      String sql = "DELETE FROM TEAM_LARGE_HIS WHERE TNUM=? and MNUM=?";
         Object[] param = new Object[] {TLHistory.getTeamNum(), TLHistory.getMemberNum()};            
         jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
            
         try {            
            int result = jdbcUtil.executeUpdate();   // update �� ����
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         }
         finally {
            jdbcUtil.commit();
            jdbcUtil.close();   // resource ��ȯ
         }      
         return 0;
   }
   
   public List<TeamLargeHis> findTeamLargeHisList() throws SQLException {
      String sql = "SELECT TNUM, MNUM "
            + "FROM TEAM_LARGE_HIS ORDER BY TNUM"; 
      
         jdbcUtil.setSqlAndParameters(sql,null);

         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<TeamLargeHis> tlHisList = new ArrayList<TeamLargeHis>();
            while(rs.next()) {
               TeamLargeHis tlHis = new TeamLargeHis(
                     rs.getInt("tnum"),
                     rs.getInt("mnum"));
               tlHisList.add(tlHis);   
            }   
            return tlHisList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
   
   public List<TeamLargeHis> findTeamLargeHisListByMnum(int mnum) throws SQLException {
      String sql = "SELECT TNUM, MNUM "
            + "FROM TEAM_LARGE_HIS WHERE MNUM=? ORDER BY TNUM"; 
      
          Object[] param = new Object[] {mnum};            
          jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
           
         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<TeamLargeHis> tlHisList = new ArrayList<TeamLargeHis>();
            while(rs.next()) {
               TeamLargeHis tlHis = new TeamLargeHis(
                     rs.getInt("tnum"),
                     rs.getInt("mnum"));
               tlHisList.add(tlHis);   
            }   
            return tlHisList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
   
   public boolean existingTeamLargeHis(int tNum, int mNum) throws SQLException {
         String sql = "SELECT count(*) FROM TEAM_LARGE_HIS WHERE tnum=? AND mnum=?";      
         jdbcUtil.setSqlAndParameters(sql, new Object[] {tNum, mNum});   // JDBCUtil�� query���� �Ű� ���� ����

         try {
            ResultSet rs = jdbcUtil.executeQuery();      // query ����
            if (rs.next()) {
               int count = rs.getInt(1);
               return (count == 1 ? true : false);
            }
         } catch (Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();      // resource ��ȯ
         }
         return false;
      }
   
   /**
    * ������� ���� �ο��� ���
    */
   public int countLimit(int tNum) {
         
         String sql = "SELECT COUNT(mnum) "
               + "FROM TEAM_LARGE_HIS "
               + "WHERE TNUM=?";
         
         jdbcUtil.setSqlAndParameters(sql, new Object[] {tNum}); //jdbcUtil�� query���� �Ű����� ����
         
         try {
            ResultSet rs = jdbcUtil.executeQuery();
            if (rs.next()) {
               return rs.getInt(1);
            }
         } catch (Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return 0;
      }

}