package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import model.Field;
import model.Mentee;
import model.Mentor;
import model.TeamSmall;

public class TeamSmallDAO{
   private JDBCUtil jdbcUtil = null;
   
   public TeamSmallDAO(){
      jdbcUtil = new JDBCUtil();
   }

   //���ο� �� ����
   public int create(TeamSmall teamSmall) throws SQLException {    
      String sql = "INSERT INTO TEAM_SMALL (tnum, tname, start_date, field, "
            + "meeting_loc, end_date, support, mentornum) "
         + "VALUES(seq_tsnum.nextval,?,SYSDATE,?,?,?,?,?)";
      
      try {
         java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
         java.util.Date utilDate = df.parse(teamSmall.getEndDate());
         
         Object[] param = new Object[] {teamSmall.getName(),teamSmall.getField1(),teamSmall.getMeetingLoc(), 
            new java.sql.Date(utilDate.getTime()),teamSmall.getSupport(), teamSmall.getMentorNum()};
         
         jdbcUtil.setSqlAndParameters(sql,param);

      }catch (ParseException e) {
        // TODO Auto-generated catch block
           e.printStackTrace();
       }
      
      try {
         int result = jdbcUtil.executeUpdate();
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      } finally {
         jdbcUtil.commit();
         jdbcUtil.close();
      } 
      return 0;
   }

   public int update(TeamSmall teamS) throws SQLException {   
      String sql = "UPDATE TEAM_SMALL " + "SET meeting_loc=? "
               + "WHERE TNUM=?";
         Object[] param = new Object[] {teamS.getMeetingLoc(), teamS.getNum()};            
         jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
            
         try {            
            int result = jdbcUtil.executeUpdate();   // update �� ����
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         }
         finally {
            jdbcUtil.commit();
            jdbcUtil.close();   // resource ��ȯ
         }      
         return 0;
   }
   
   /**
    * TEAM_SMALL ����
    */
   public int remove(int teamNum) throws SQLException {
      String sql = "DELETE FROM TEAM_SMALL WHERE TNUM=?";
         Object[] param = new Object[] {teamNum};            
         jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
            
         try {            
            int result = jdbcUtil.executeUpdate();   // update �� ����
            return result;
         } catch (Exception ex) {
            jdbcUtil.rollback();
            ex.printStackTrace();
         }
         finally {
            jdbcUtil.commit();
            jdbcUtil.close();   // resource ��ȯ
         }      
         return 0;
   }
   
   /**
    * tnum�� �ش��ϴ� ts list ���� ���
    */
//   public List<TeamSmall> findTeamSmallList(int tnum) throws SQLException {
//	      String sql = "SELECT t.tnum, t.tname, f.fieldname, t.meeting_loc, t.end_date, t.mnum " + 
//	            "FROM (SELECT m.tnum, ts.tname, ts.field, ts.meeting_loc, ts.end_date, m.mnum " + 
//	            "        FROM (TEAM_SMALL ts JOIN MENTEE m " + 
//	            "        ON ts.tnum = m.tnum )) t RIGHT OUTER JOIN Field f " + 
//	            "                                ON t.field = f.fieldnum " + 
//	            "WHERE t.tnum=?";
//	          Object[] param = new Object[] {tnum};  
//	         jdbcUtil.setSqlAndParameters(sql,param);
//	       
//	         
//	        
//	         try {
//	            ResultSet rs = jdbcUtil.executeQuery();
//	            List<TeamSmall> tsList = new ArrayList<TeamSmall>();
//	         
//	            while(rs.next()) {
//	               java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
//	               java.util.Date utilDate = new java.util.Date(rs.getDate("end_date").getTime());
//	               String dateString = df.format(utilDate);
//	               Mentee mentee = new Mentee();
//	               mentee.setMnum(rs.getInt("mnum"));
//	            
//	                  TeamSmall ts = new TeamSmall(
//	                        rs.getInt("tnum"),
//	                        rs.getString("tname"),
//	                        rs.getInt("field"),
//	                        rs.getString("meeting_loc"),
//	                        dateString);//rs.getDate("end_date"));
//	                  ts.setMentee(mentee); //ts.getMentee().setMnum(rs.getInt("mnum"));
//	                  tsList.add(ts);   
//	               }   
//	               return tsList;
//	               
//	         } catch(Exception ex) {
//	            ex.printStackTrace();
//	         } finally {
//	            jdbcUtil.close();
//	         }
//	         return null;
//	   }
   
   /**
    * TNUM PK�� ���� TEAM_SMALLã��
    */
   public TeamSmall findTeamSmall(int teamNum) throws SQLException {
      String sql = "SELECT tnum, tname, start_date, field, meeting_loc, end_date, support, mentornum "
          + "FROM TEAM_SMALL "
            + "WHERE TNUM=? ";         
                      
      jdbcUtil.setSqlAndParameters(sql, new Object[] {teamNum});   // JDBCUtil�� query���� �Ű� ���� ����

      try {
           ResultSet rs = jdbcUtil.executeQuery();      // query ����
           
           if (rs.next()) {          
              java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
              
              java.util.Date utilDate = new java.util.Date(rs.getDate("end_date").getTime());
              String dateString = df.format(utilDate);
           
              java.util.Date utilDate2 = new java.util.Date(rs.getDate("start_date").getTime());
              String dateString2 = df.format(utilDate2);    
              
              TeamSmall teamS = new TeamSmall(
                       rs.getInt("tnum"),
                       rs.getString("tname"), 
                       dateString2,
                       rs.getInt("field"), 
                       rs.getString("meeting_loc"), 
                       dateString,
                       rs.getInt("support"),
                       rs.getInt("mentorNum"));
              return teamS;
           }
        } catch (Exception ex) {
           ex.printStackTrace();
        } finally {
           jdbcUtil.close();      // resource ��ȯ
        }
        return null;
   }
   
   /**
    * TNAME�� ���� TEAM_SMALLã��
    */
   public TeamSmall findTeamSmallByNAME(String name) throws SQLException {
	      String sql1 = "SELECT tnum, tname, start_date, field, meeting_loc, end_date, support, mentornum "
	          + "FROM TEAM_SMALL "
	            + "WHERE TNAME=? ";         
	                      
	      jdbcUtil.setSqlAndParameters(sql1, new Object[] {name});   // JDBCUtil�� query���� �Ű� ���� ����

	      try {
	           ResultSet rs = jdbcUtil.executeQuery();      // query ����   
	           
	           if (rs.next()) {    
	              java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
	        
	              java.util.Date utilDate2 = new java.util.Date(rs.getDate("start_date").getTime());
	              String dateString2 = df.format(utilDate2);          
	              
	              java.util.Date utilDate = new java.util.Date(rs.getDate("end_date").getTime());
	               String dateString = df.format(utilDate);
	              
	               TeamSmall teamS = new TeamSmall(
	                       rs.getInt("tnum"),
	                       rs.getString("tname"), 
	                       dateString2,
	                       rs.getInt("field"), 
	                       rs.getString("meeting_loc"), 
	                       dateString,
	                       rs.getInt("support"),
	                       rs.getInt("mentorNum"));
	              return teamS;
	           }
	        } catch (Exception ex) {
	           ex.printStackTrace();
	        } finally {
	           jdbcUtil.close();      // resource ��ȯ
	        }
	        return null;
	   }
   
   /**
    * �������� Ȱ���о� �̸� ã��
    */
   public String findTeamSmallFieldByName(String name) throws SQLException {
        
	   String sql = "SELECT fieldname "
			   		+ "FROM TEAM_SMALL, FIELD "
			   		+ "WHERE TNAME = ? and TEAM_SMALL.field = field.fieldnum";              
	  
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {name});   // JDBCUtil�� query���� �Ű� ���� ����

	      try {
	           ResultSet rs = jdbcUtil.executeQuery();      // query ����   
	           
	           if (rs.next()) {    
	        	   
	               String fieldname = rs.getString("fieldname");
	              return fieldname;
	           }
	        } catch (Exception ex) {
	           ex.printStackTrace();
	        } finally {
	           jdbcUtil.close();      // resource ��ȯ
	        }
	        return null;
	   }
   
   
   /**
    * team_small list ��ȯ
    */
   public List<TeamSmall> findTeamSmallList() {
      
	   String sql = "SELECT tnum, tname, start_date, t.field, f.fieldname, meeting_loc, end_date, support, mentornum "
			   			+ "FROM TEAM_SMALL t, FIELD f WHERE t.field = f.fieldnum ORDER BY TNUM";
      
         jdbcUtil.setSqlAndParameters(sql,null);

         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<TeamSmall> teamList = new ArrayList<TeamSmall>();
         
            while(rs.next()) {
               java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
               
               java.util.Date utilDate = new java.util.Date(rs.getDate("start_date").getTime());
               String dateString = df.format(utilDate);
               
               java.util.Date utilDate2 = new java.util.Date(rs.getDate("end_date").getTime());
               String dateString2 = df.format(utilDate2);
             
               Field field = new Field();
           		field.setFname(rs.getString("fieldname"));
           		
               TeamSmall teamS = new TeamSmall(
                     rs.getInt("tnum"),
                     rs.getString("tname"), 
                       dateString2,
                       rs.getInt("field"), 
                       rs.getString("meeting_loc"), 
                       dateString,
                       rs.getInt("support"),
                       rs.getInt("mentorNum"));
               teamS.setField(field);
               teamList.add(teamS);   
            }   
            return teamList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
   
   public List<TeamSmall> findByFieldTeamSmallList(int field) throws SQLException {
      String sql = "SELECT tnum, tname, start_date, field, meeting_loc, end_date, support, mentornum "
            + "FROM TEAM_SMALL " 
            + "WHERE FIELD=? "
            + "ORDER BY TNUM"; 
         
         jdbcUtil.setSqlAndParameters(sql, new Object[] {field});

         try {
            ResultSet rs = jdbcUtil.executeQuery();
            List<TeamSmall> teamList = new ArrayList<TeamSmall>();
            
            while(rs.next()) {
               java.text.DateFormat df = new java.text.SimpleDateFormat("yyyy/MM/dd");
              
               java.util.Date utilDate = new java.util.Date(rs.getDate("start_date").getTime());
               String dateString = df.format(utilDate);
               
               java.util.Date utilDate2 = new java.util.Date(rs.getDate("end_date").getTime());
               String dateString2 = df.format(utilDate2);
              
               TeamSmall teamS = new TeamSmall(
                     rs.getInt("tnum"),
                     rs.getString("tname"), 
                       dateString2,
                       rs.getInt("field"), 
                       rs.getString("meeting_loc"), 
                       dateString,
                       rs.getInt("support"),
                       rs.getInt("mentorNum"));
               teamList.add(teamS);   
            }   
            return teamList;
         } catch(Exception ex) {
            ex.printStackTrace();
         } finally {
            jdbcUtil.close();
         }
         return null;
   }
   
   public int updateSupport(TeamSmall teamS, int teamNum, int expense) throws SQLException {
         String sql = "UPDATE TEAM_SMALL " + "SET support=? "
                  + "WHERE TNUM=?";
            Object[] param = new Object[] {teamS.getSupport() - expense, teamS.getNum()};            
            jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil�� update���� �Ű� ���� ����
               
            try {            
               int result = jdbcUtil.executeUpdate();   // update �� ����
               return result;
            } catch (Exception ex) {
               jdbcUtil.rollback();
               ex.printStackTrace();
            }
            finally {
               jdbcUtil.commit();
               jdbcUtil.close();   // resource ��ȯ
            }      
            return 0;
   }
   
  
   public List<TeamSmall> findTnameByMnum(int mnum) throws SQLException{
	      String sql = "SELECT team_small.tname, team_small.tnum, team_small.mentornum FROM team_small, mentee, member "
	            + "WHERE member.mnum=? and team_small.tnum = mentee.tnum and mentee.mnum = member.mnum";  
	      jdbcUtil.setSqlAndParameters(sql,new Object[] {mnum});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         List<TeamSmall> tl = new ArrayList<TeamSmall>();
	         
	         while(rs.next()) {
	            TeamSmall ts = new TeamSmall();
	            ts.setName(rs.getString("tname"));
	            ts.setNum(rs.getInt("tnum"));
	            ts.setMentorNum(rs.getInt("mentornum"));
	            tl.add(ts);
	         }
	         return tl;
	      } catch(Exception ex) {
	           ex.printStackTrace();
	        } finally {
	           jdbcUtil.close();
	        }
	        return null;
	   }
   
   public List<TeamSmall> findTnameMentorByMnum(int mnum) throws SQLException{
	      String sql = "SELECT team_small.tname FROM team_small, mentor, member "
	            + "WHERE member.mnum=? and team_small.mentornum = mentor.mentornum and mentor.mnum = member.mnum";
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {mnum});
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         List<TeamSmall> tlist = new ArrayList<TeamSmall>();
	         
	         while(rs.next()) {
	            TeamSmall ts = new TeamSmall();
	            ts.setName(rs.getString("tname"));
	            tlist.add(ts);
	         }
	         return tlist;
	      } catch(Exception ex) {
	           ex.printStackTrace();
	        } finally {
	           jdbcUtil.close();
	        }
	        return null;
	   }

   public boolean existingTeamSmall(String teamName) throws SQLException {
      String sql = "SELECT count(*) FROM team_small WHERE tname=?";      
      jdbcUtil.setSqlAndParameters(sql, new Object[] {teamName});   // JDBCUtil�� query���� �Ű� ���� ����

      try {
         ResultSet rs = jdbcUtil.executeQuery();      // query ����
         if (rs.next()) {
            int count = rs.getInt(1);
            return (count == 1 ? true : false);
         }
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.close();      // resource ��ȯ
      }
      return false;
   }
   
   
}