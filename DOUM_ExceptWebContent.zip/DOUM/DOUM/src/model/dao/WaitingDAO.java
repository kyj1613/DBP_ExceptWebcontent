package model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.team.ListWaitingController;
import model.TeamSmall;
import model.Waiting;

public class WaitingDAO {
	private static final Logger log = LoggerFactory.getLogger(WaitingDAO.class);
private JDBCUtil jdbcUtil = null;
   
   public WaitingDAO() {         
      jdbcUtil = new JDBCUtil();   // JDBCUtil ��ü ����
   }
      
   /**
    * ����� ���� ���̺��� ���ο� ����� ����.
    */
   public int create(Waiting waiting) throws SQLException {
      String sql = "INSERT INTO WAITING "
            + "VALUES (seq_waitnum.nextval, ?, ?, ?)";
      Object[] param = new Object[] {waiting.getMname(), waiting.getMnum(), waiting.getTnum()};            
      jdbcUtil.setSqlAndParameters(sql, param);   // JDBCUtil �� insert���� �Ű� ���� ����
                  
      try {            
         int result = jdbcUtil.executeUpdate();   // insert �� ����
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      } finally {      
         jdbcUtil.commit();
         jdbcUtil.close();   // resource ��ȯ
      }      
      return 0;         
   }
   
   public int remove(int tNum, int waitNum) throws SQLException {
      String sql = "DELETE FROM WAITING WHERE tnum=? and waitnum=?";      
      jdbcUtil.setSqlAndParameters(sql, new Object[] {tNum, waitNum});   // JDBCUtil�� delete���� �Ű� ���� ����

      try {            
         int result = jdbcUtil.executeUpdate();   // delete �� ����
         return result;
      } catch (Exception ex) {
         jdbcUtil.rollback();
         ex.printStackTrace();
      }
      finally {
         jdbcUtil.commit();
         jdbcUtil.close();   // resource ��ȯ
      }      
      return 0;
   }
   public int removeWaiting(Waiting waiting) throws SQLException {
	      String sql = "DELETE FROM WAITING WHERE waitnum=?";      
	      jdbcUtil.setSqlAndParameters(sql, new Object[] {waiting.getWaitnum()});   // JDBCUtil�� delete���� �Ű� ���� ����

	      try {            
	         int result = jdbcUtil.executeUpdate();   // delete �� ����
	         return result;
	      } catch (Exception ex) {
	         jdbcUtil.rollback();
	         ex.printStackTrace();
	      }
	      finally {
	         jdbcUtil.commit();
	         jdbcUtil.close();   // resource ��ȯ
	      }      
	      return 0;
	   }
   
   public List<Waiting> findWaitingList(int tnum) throws SQLException {
        String sql = "SELECT * " 
                 + "FROM WAITING "
                 + "WHERE TNUM=? ";
      jdbcUtil.setSqlAndParameters(sql, new Object[] {tnum});      // JDBCUtil�� query�� ����
               
      try {
         ResultSet rs = jdbcUtil.executeQuery();         // query ����         
         List<Waiting> waitingList = new ArrayList<Waiting>();   // User���� ����Ʈ ����
         while (rs.next()) {
            Waiting waiting = new Waiting(         // User ��ü�� �����Ͽ� ���� ���� ������ ����
            		rs.getInt("waitnum"),
               rs.getString("mname"),
               rs.getInt("mnum"),
               rs.getInt("tnum")
               );
            waitingList.add(waiting);            // List�� User ��ü ����
            
         }      
      
         return waitingList;               
         
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.close();      // resource ��ȯ
      }
      return null;
   }
   public List<Waiting> findWaitingMnumList(int mnum) throws SQLException {
       String sql = "SELECT waitnum, mname, mnum, waiting.tnum, tname " 
                + "FROM WAITING, team_small "
                + "WHERE waiting.tnum = team_small.tnum and MNUM=? ";

     jdbcUtil.setSqlAndParameters(sql, new Object[] {mnum});      // JDBCUtil�� query�� ����
              
     try {
        ResultSet rs = jdbcUtil.executeQuery();         // query ����         
        List<Waiting> waitingList = new ArrayList<Waiting>();   // User���� ����Ʈ ����
        while (rs.next()) {
        	
        	TeamSmall teamSmall = new TeamSmall();
            teamSmall.setName(rs.getString("tname"));
           Waiting waiting = new Waiting(         // User ��ü�� �����Ͽ� ���� ���� ������ ����
              rs.getString("mname"),
              rs.getInt("mnum"),
              rs.getInt("tnum"));
           
           waiting.setTeamSmall(teamSmall);
           waitingList.add(waiting);            // List�� User ��ü ����
           
        }      
       
        return waitingList;               
        
     } catch (Exception ex) {
        ex.printStackTrace();
     } finally {
        jdbcUtil.close();      // resource ��ȯ
     }
     return null;
  }
   
   public Waiting findWaitNum(int tnum, int mnum) throws SQLException{
	      String sql = "SELECT waitnum,mname FROM WAITING "
	            + "WHERE tnum=? and mnum=?";
	      jdbcUtil.setSqlAndParameters(sql,  new Object[] {tnum,mnum});
	      
	      try {
	         ResultSet rs = jdbcUtil.executeQuery();
	         if(rs.next()) {
	            Waiting waiting = new Waiting(
	                  rs.getInt("waitnum"),
	                  rs.getString("mname"));
	            return waiting;
	         }
	      }catch (Exception ex) {
	            ex.printStackTrace();
	         } finally {
	            jdbcUtil.close();      // resource ��ȯ
	         }
	      return null;
	      }
   public int findLastWaitNum(int tnum) throws SQLException {
      String sql = "SELECT COUNT(WAITNUM) "
            + "FROM WAITING "
            + "WHERE TNUM=?";
         
      jdbcUtil.setSqlAndParameters(sql, new Object[] {tnum});   
         
      try {
         ResultSet rs = jdbcUtil.executeQuery();      // query ����
          if (rs.next()) {
             int count = rs.getInt(1);
              return count;
          }
      } catch (Exception ex) {
         ex.printStackTrace();
      } finally {
         jdbcUtil.close();      // resource ��ȯ
      }
      return -1;
   }
}