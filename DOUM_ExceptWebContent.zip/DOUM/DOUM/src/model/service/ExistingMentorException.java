package model.service;

public class ExistingMentorException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExistingMentorException() {
		super();
	}

	public ExistingMentorException(String arg0) {
		super(arg0);
	}
}
