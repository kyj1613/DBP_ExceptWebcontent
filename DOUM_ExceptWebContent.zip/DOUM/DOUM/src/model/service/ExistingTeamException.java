package model.service;

public class ExistingTeamException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ExistingTeamException() {
		super();
	}

	public ExistingTeamException(String arg0) {
		super(arg0);
	}
}
