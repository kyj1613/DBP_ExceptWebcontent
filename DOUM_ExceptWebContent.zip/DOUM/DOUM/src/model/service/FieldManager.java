package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Field;
import model.dao.FieldDAO;

public class FieldManager {
   private static FieldManager fieldMan = new FieldManager();
   private FieldDAO fieldDAO;
   
   private FieldManager() {
      try {
         fieldDAO = new FieldDAO();
      
      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static FieldManager getInstance() {
      return fieldMan;
   }
   
   public String findFieldByNum (int fnum) throws SQLException {
         return fieldDAO.findFieldByNum(fnum);
   }
   
   public List<Field> findFieldList(String fname) throws SQLException {
         return fieldDAO.findFieldList(fname);
   }

   public FieldDAO getFieldDAO() {
      return this.fieldDAO;
   }
}