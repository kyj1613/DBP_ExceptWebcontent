package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Location;
import model.dao.LocationDAO;

public class LocationManager {
   private static LocationManager Ltman = new LocationManager();
   private LocationDAO locDAO;
   
   private LocationManager() {
      try {
    	  locDAO = new LocationDAO();
        
      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static LocationManager getInstance() {
      return Ltman;
   }
   


   public Location findLocationByName(String locname) throws SQLException {
      return locDAO.findLocationByName(locname);
   }

   public List<Location> findLocationList() {
	// TODO Auto-generated method stub
	   return locDAO.findLocationList();
   }
   public Location findLocationByCity(String city) throws SQLException {
       return locDAO.findLocationByCity(city);
    }
    
    public Location findLocationByLoc(String locname) throws SQLException{
       return locDAO.findLocationByLoc(locname);
    }
    public Location findLocationByLocRoom(int locnum, int roomnum) throws SQLException{
        return locDAO.findLocationByLocRoom(locnum, roomnum);
     }
    public Location findLocationByLocNum(int locnum) throws SQLException{
    	return locDAO.findLocationByLocNum(locnum);
    }
    
	public List<Location> findDistinctLocationList() {
		// TODO Auto-generated method stub
		return locDAO.findDistinctLocationList();
	}
	
    public LocationDAO getLocationDAO() {
          return this.locDAO;
    }



}