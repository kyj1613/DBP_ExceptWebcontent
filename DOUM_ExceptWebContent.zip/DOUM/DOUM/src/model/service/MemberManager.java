package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Member;
import model.Mentor;
import model.dao.MemberDAO;

public class MemberManager {
   private static MemberManager memberMan = new MemberManager();
   private MemberDAO memberDAO;
  
   private MemberManager() {
      try {
         memberDAO = new MemberDAO();
      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static MemberManager getInstance() {
      return memberMan;
   }
   
   public int create(Member member) throws SQLException, ExistingMemberException {
      if (memberDAO.existingMember(member.getId()) == true) {
         throw new ExistingMemberException(member.getId() + "�� �����ϴ� ���̵��Դϴ�.");
      }
      return memberDAO.create(member);
   }

   public int update(Member member) throws SQLException {
      return memberDAO.update(member);
   } 
   
   public Member findMember(String id)
      throws SQLException, MemberNotFoundException {
      Member member = memberDAO.findMember(id);
      
      if (member == null) {
         throw new MemberNotFoundException(id + "�� �������� �ʴ� ���̵��Դϴ�.");
      }      
      return member;
   }

   public Member findMemberByName(String mname) throws SQLException, MemberNotFoundException {
         Member member = memberDAO.findMemberByName(mname);
         
         if (member==null) {
            throw new MemberNotFoundException(mname+"�� �������� �ʴ� ����Դϴ�.");
         }
         return member;
      }
   
   /*public List<User> findUserList() throws SQLException {
         return userDAO.findUserList();
   }
   
   public List<User> findUserList(int currentPage, int countPerPage)
      throws SQLException {
      return userDAO.findUserList(currentPage, countPerPage);
   }*/

   public boolean login(String id, String password)
      throws SQLException, MemberNotFoundException, PasswordMismatchException {
      Member member = findMember(id);

      if (!member.matchPassword(password)) {
         throw new PasswordMismatchException("��й�ȣ�� ��ġ���� �ʽ��ϴ�.");
      }
      return true;
   }

   /*public List<User> makeFriends(String userId) throws Exception {
      return userAanlysis.recommendFriends(userId);
   }*/
   
   public List<Mentor> recommendMentors(int fieldNum) throws Exception {
         return memberDAO.recommendMentors(fieldNum);
      }
   public boolean register(String id) throws SQLException, MemberNotFoundException, SameUserIdException {
         Member member = findMember(id);

         if (member != null) {
            throw new SameUserIdException("����� �� ���� ���̵��Դϴ�.");
         }
         return true;
      }
   public MemberDAO getMemberDAO() {
         return this.memberDAO;
      }
   
}