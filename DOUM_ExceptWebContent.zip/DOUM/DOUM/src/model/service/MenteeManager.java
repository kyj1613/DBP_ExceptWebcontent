package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Mentee;
import model.dao.MenteeDAO;


public class MenteeManager {
   private static MenteeManager menteeMan = new MenteeManager();
   private MenteeDAO menteeDAO;
   
   private MenteeManager() {
      try {
         menteeDAO = new MenteeDAO();
      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static MenteeManager getInstance() {
      return menteeMan;
   }
      
   public int create(Mentee mentee) throws SQLException{
      return menteeDAO.create(mentee);
   }
      
   public int remove(Mentee mentee) throws SQLException {
      return menteeDAO.remove(mentee);
   }
   public int removeByTnum(Mentee mentee) throws SQLException {
	      return menteeDAO.removeByTnum(mentee);
	   }
   
   public List<Mentee> findMenteeList() throws SQLException {   
      return menteeDAO.findMenteeList();
   }
   public List<Mentee> findMenteeList(int teamNum) throws SQLException {   
         return menteeDAO.findMenteeList(teamNum);
      }
   public List<Mentee> findTnumByMnum(int mnum) throws SQLException{
      return menteeDAO.findTnumByMnum(mnum);
   }
   public int countMentee(int teamNum) {
      return menteeDAO.countMentee(teamNum);
   }
   
   public MenteeDAO getMenteeDAO() {
      return this.menteeDAO;
   }
}