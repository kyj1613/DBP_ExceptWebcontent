package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Mentor;
import model.dao.MentorDAO;

public class MentorManager {
	private static MentorManager mentorMan = new MentorManager();
	private MentorDAO mentorDAO;

	private MentorManager() {
		try {
			mentorDAO = new MentorDAO();

		} catch (Exception e) {
			e.printStackTrace();
		}			
	}
	
	public static MentorManager getInstance() {
		return mentorMan;
	}
	
	public int create(Mentor mentor) throws SQLException, ExistingMentorException {
	      
	      return mentorDAO.create(mentor);
	   }

	public int update(Mentor mentor) throws SQLException {
		return mentorDAO.update(mentor);
	}	

	public int updateStar(Mentor mentor) throws SQLException {
		return mentorDAO.updateStar(mentor);
	}	

	public Mentor findMentor(int mentorNum) throws SQLException, MentorNotFoundException {
		Mentor mentor = mentorDAO.findMentor(mentorNum);
		
		if (mentor == null) {
			throw new MentorNotFoundException(mentor.getMember().getName() + "�� �������� �ʴ� �����Դϴ�.");
		}		
		return mentor;
	}
	
	public Mentor findMentorById1(String id)throws SQLException {
	      return mentorDAO.findMentorById1(id);
	   }
	
	public List<Mentor> findMentorList() throws SQLException {
			return mentorDAO.findMentorList();
	}
	
	public List<Mentor> findByFieldMentorList(int field) throws SQLException {
	      return mentorDAO.findByFieldMentorList(field);
	   }

	public MentorDAO getMentorDAO() {
		return this.mentorDAO;
	}
}
