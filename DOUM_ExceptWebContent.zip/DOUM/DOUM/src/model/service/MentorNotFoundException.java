package model.service;

public class MentorNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MentorNotFoundException() {
		super();
	}

	public MentorNotFoundException(String arg0) {
		super(arg0);
	}
}
