package model.service;

import java.sql.SQLException;
import java.util.List;

import model.RentHis;
import model.TeamSmall;
import model.dao.RentHisDAO;

public class RentHisManager {
   private static RentHisManager Rtman = new RentHisManager();
   private RentHisDAO RtDAO;


   private RentHisManager() {
      try {
    	  RtDAO = new RentHisDAO();

      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static RentHisManager getInstance() {
      return Rtman;
   }
   
   public int create(RentHis rentHis) throws SQLException {
      return RtDAO.create(rentHis);
   }

   public List<RentHis> findRentHisList() throws SQLException {
       return RtDAO.findRentHisList();
   }

   public int remove(RentHis rentHis) throws SQLException{
	      return RtDAO.remove(rentHis);
	   }
   public int removeTnum(RentHis rentHis) throws SQLException{
	      return RtDAO.remove(rentHis);
	   }
	   
	   public List<RentHis> findRentHisList(String locname) throws SQLException {
	      return RtDAO.findRentHisList(locname);
	   }
	   
//	   public int countRentHis(RentHis rentHis) throws SQLException{
//		      return RtDAO.countRentHis(rentHis);
//		   }
	   public List<RentHis> findRentHisTnumList(int tnum) throws SQLException {
		      return RtDAO.findRentHisTnumList(tnum);
		   }
	   
	   public List<RentHis> findRentHisLocnumRoomnumList(int locnum, int roomnum) throws SQLException {
		   return RtDAO.findRentHisLocnumRoomnumList(locnum, roomnum);
	   }
	   
	   public RentHisDAO getRentHisDAO() {
		      return this.RtDAO;
		   }


}