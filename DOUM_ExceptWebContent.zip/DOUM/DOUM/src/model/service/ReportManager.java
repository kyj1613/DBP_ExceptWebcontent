package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Report;
import model.dao.ReportDAO;

public class ReportManager {
   private static ReportManager repMan = new ReportManager();
      private ReportDAO repDAO;

      private ReportManager() {
         try {
            repDAO = new ReportDAO();
         } catch (Exception e) {
            e.printStackTrace();
         }         
      }
    
      public static ReportManager getInstance() {
         return repMan;
      }
      
      public int create(Report report) throws SQLException {
         return repDAO.create(report);
      }
      
      public int update(Report report) throws SQLException {
         return repDAO.update(report);
      }
      
      public int remove(int rptNum) throws SQLException {
         return repDAO.remove(rptNum);
      }
      public int removeTnum(Report report) throws SQLException {
          return repDAO.removeTnum(report);
       }
     
      public List<Report> findReportList(int tnum) throws SQLException {
         return repDAO.findReportList(tnum);
      }
      
      public ReportDAO getReportDAO() {
            return this.repDAO;
      }
}