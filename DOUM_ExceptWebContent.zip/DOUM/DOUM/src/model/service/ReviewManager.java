package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Review;
import model.dao.ReviewDAO;

public class ReviewManager {
   
   private static ReviewManager revMan = new ReviewManager();
   private ReviewDAO reviewDAO;
   
   private ReviewManager() {
      try {
         reviewDAO = new ReviewDAO();
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
   
   public static ReviewManager getInstance() {
      return revMan;
   }
   
   public int create(Review review) throws SQLException{
      return reviewDAO.create(review);
   }
   
//   public int update(Review review) throws SQLException{
//      return reviewDAO.update(review);
//   }
//   
//   public int remove(Review review) throws SQLException {
//      return reviewDAO.remove(review);
//   }
//   public Review findReview(int revnum) throws SQLException{
//      return reviewDAO.findReview(revnum);
//   }
   
   public Review findReviewTitle(String revtitle) throws SQLException{
	      return reviewDAO.findReviewTitle(revtitle);
	   }
   
   public List<Review> findReviewList(){
      return reviewDAO.findReviewList();
   }
   public int upHit(int revnum) throws SQLException{
	      return reviewDAO.upHit(revnum);
	   }

   public Review findReviewTitleMnum(int revnum) throws SQLException{
	   return reviewDAO.findReviewTitleMnum(revnum);
   }
   
   public ReviewDAO getReviewDAO() {
      return this.reviewDAO;
   }

   public Review findReviewTitleStarMnum(int revnum) throws SQLException{
	// TODO Auto-generated method stub
	return reviewDAO.findReviewTitleStarMnum(revnum);
   }
   

}