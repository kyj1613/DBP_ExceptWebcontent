package model.service;

public class SameUserIdException extends Exception {
   private static final long serialVersionUID = 1L;

   public SameUserIdException() {
      super();
   }

   public SameUserIdException(String arg0) {
      super(arg0);
   }

}