package model.service;

import java.sql.SQLException;
import java.util.List;

import model.Star;
import model.dao.StarDAO;

public class StarManager {
	private static StarManager starman = new StarManager();
	private StarDAO starDAO;

	private StarManager() {
		try {
			starDAO = new StarDAO();
		} catch (Exception e) {
			e.printStackTrace();
		}			
	}
	
	public static StarManager getInstance() {
		return starman;
	}
	
	public int create(Star star) throws SQLException {
		return starDAO.create(star);
	}

	public int update(Star star) throws SQLException {
		return starDAO.update(star);
	}	

	public int remove(int reviewNum) throws SQLException {
		return starDAO.remove(reviewNum);
	}

	public List<Star> findStarListOfMentor(int mentorNum) throws SQLException {
			return starDAO.findStarListOfMentor(mentorNum);
	}
	
	public float sumOfStar(int mentorNum) throws SQLException {
		return starDAO.sumOfStar(mentorNum);
	}
	
}
