package model.service;

import java.sql.SQLException;
import java.util.List;

import model.TeamLargeHis;
import model.dao.TeamLargeHisDAO;

public class TeamLargeHisManager {

   private static TeamLargeHisManager tlhman = new TeamLargeHisManager();
   private TeamLargeHisDAO tlhDAO;
   
   private TeamLargeHisManager() {
      try {
         tlhDAO = new TeamLargeHisDAO();
      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static TeamLargeHisManager getInstance() {
      return tlhman;
   }
   
   public int create(TeamLargeHis teamLargeHis) throws SQLException, ExistingTeamException {
      if (tlhDAO.existingTeamLargeHis(teamLargeHis.getTeamNum(), teamLargeHis.getMemberNum() ) == true) {
         throw new ExistingTeamException("�̹� ��û�߽��ϴ�.");
      }
      return tlhDAO.create(teamLargeHis);
   }
     
   
   public int remove(TeamLargeHis teamLargeHis) throws SQLException {
      return tlhDAO.remove(teamLargeHis);
   }
   
   public List<TeamLargeHis> findTeamLargeHisList() throws SQLException {
         return tlhDAO.findTeamLargeHisList();
   }
   
   public List<TeamLargeHis> findTeamLargeHisListByMnum(int mnum) throws SQLException {
      return tlhDAO.findTeamLargeHisListByMnum(mnum);
   }
     
   public int countLimit(int tNum) throws SQLException {
	   return tlhDAO.countLimit(tNum);
   }
   
   public TeamLargeHisDAO getTeamLargeHisDAO() {
      return this.tlhDAO;
   }
}