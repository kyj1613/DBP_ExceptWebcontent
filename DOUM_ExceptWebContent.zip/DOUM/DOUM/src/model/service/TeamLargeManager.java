package model.service;

import java.sql.SQLException;
import java.util.List;

import model.TeamLarge;
import model.dao.TeamLargeDAO;

public class TeamLargeManager {
   private static TeamLargeManager tlman = new TeamLargeManager();
      private TeamLargeDAO tlDAO;

      private TeamLargeManager() {
         try {
            tlDAO = new TeamLargeDAO();
         } catch (Exception e) {
            e.printStackTrace();
         }         
      }
      
      public static TeamLargeManager getInstance() {
         return tlman;
      }
      
      public int create(TeamLarge teamLarge) throws SQLException, ExistingTeamException {
         if (tlDAO.existingTeamLarge(teamLarge.getName()) == true) {
            throw new ExistingTeamException(teamLarge.getName() + "�� �����ϴ� ���Դϴ�.");
         }
         return tlDAO.create(teamLarge);
      }

      public int update(TeamLarge teamLarge) throws SQLException {
         return tlDAO.update(teamLarge);
      }   

      public int remove(int teamNum) throws SQLException {
         return tlDAO.remove(teamNum);
      }

      public TeamLarge findTeamLarge(int teamNum) throws SQLException, TeamNotFoundException {
         TeamLarge teamLarge = tlDAO.findTeamLarge(teamNum);
         
         if (teamLarge == null) {
            throw new TeamNotFoundException(teamLarge.getName() + "�� �������� �ʴ� ���Դϴ�.");
         }      
         return teamLarge;
      }

      public List<TeamLarge> findTeamLargeList() throws SQLException {
            return tlDAO.findTeamLargeList();
      }
         
      public TeamLarge findTeamLargeByName(String name) throws SQLException {
            return tlDAO.findTeamLargeByName(name);
         }
          
      public boolean existingTeamLarge(String teamName) throws SQLException {
         return tlDAO.existingTeamLarge(teamName);
      }
      public List<TeamLarge> findTnameByMnum(int mnum) throws SQLException {
            return tlDAO.findTnameByMnum(mnum);
         }
      public List<TeamLarge> findTnameMentorByMnum(int mentornum) throws SQLException {
            return tlDAO.findTnameMentorByMnum(mentornum);
         } 
      
      public List<TeamLarge> findLargeTnameMentorByMnum(int mnum) throws SQLException {
          return tlDAO.findLargeTnameMentorByMnum(mnum);
       }
      
      
      
      public TeamLargeDAO getTeamLargeDAO() {
         return this.tlDAO;
      }

	public String findTeamLargeFieldByName(String teamname) throws SQLException {
		// TODO Auto-generated method stub
		return tlDAO.findTeamLargeFieldByName(teamname);
	}
}