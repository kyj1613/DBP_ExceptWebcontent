package model.service;

public class TeamNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TeamNotFoundException() {
		super();
	}

	public TeamNotFoundException(String arg0) {
		super(arg0);
	}
}
