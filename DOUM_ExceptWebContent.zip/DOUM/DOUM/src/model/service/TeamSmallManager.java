package model.service;

import java.sql.SQLException;
import java.util.List;

import model.TeamSmall;
import model.dao.TeamSmallDAO;

public class TeamSmallManager {
   private static TeamSmallManager tsman = new TeamSmallManager();
   private TeamSmallDAO tsDAO;
  
   private TeamSmallManager() {
      try {
         tsDAO = new TeamSmallDAO();
      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static TeamSmallManager getInstance() {
      return tsman;
   }
   
   public int create(TeamSmall teamSmall) throws SQLException, ExistingTeamException {
      if (tsDAO.existingTeamSmall(teamSmall.getName()) == true) {
         throw new ExistingTeamException(teamSmall.getName() + "�� �����ϴ� ���Դϴ�.");
      }
      return tsDAO.create(teamSmall);
   }

   public int update(TeamSmall teamSmall) throws SQLException {
      return tsDAO.update(teamSmall);
   }   

   public int remove(int teamNum) throws SQLException {
      return tsDAO.remove(teamNum);
   }

   public TeamSmall findTeamSmall(int teamNum) throws SQLException, TeamNotFoundException {
      TeamSmall teamSmall = tsDAO.findTeamSmall(teamNum);
      
      if (teamSmall == null) {
         throw new TeamNotFoundException(teamSmall.getName() + "�� �������� �ʴ� ���Դϴ�.");
      }      
      return teamSmall;
   }

   public List<TeamSmall> findTeamSmallList() throws SQLException {
         return tsDAO.findTeamSmallList();
   }
   public TeamSmall findTeamSmallByNAME(String name) throws SQLException {
	      return tsDAO.findTeamSmallByNAME(name);
	   }
   public String findTeamSmallFieldByNAME(String name) throws SQLException {
	      return tsDAO.findTeamSmallFieldByName(name);
	   }
   public int updateSupport(TeamSmall teamS, int teamNum, int expense) throws SQLException {
      return tsDAO.updateSupport(teamS, teamNum, expense);
   }  
   public boolean existingTeamSmall(String teamName) throws SQLException {
      return tsDAO.existingTeamSmall(teamName);
   }
   public List<TeamSmall> findTnameByMnum(int mnum) throws SQLException {
	      return tsDAO.findTnameByMnum(mnum);
	   }
   public List<TeamSmall> findTnameMentorByMnum(int mnum) throws SQLException {
	      return tsDAO.findTnameMentorByMnum(mnum);
	   }
   public TeamSmallDAO getTeamSmallDAO() {
      return this.tsDAO;
   }
}