package model.service;

import java.sql.SQLException;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import controller.team.ListWaitingController;
import model.Waiting;
import model.dao.WaitingDAO;

public class WaitingManager {
	private static final Logger log = LoggerFactory.getLogger(WaitingManager.class);
   private static WaitingManager waitingMan = new WaitingManager();
   private WaitingDAO waitingDAO;

   private WaitingManager() {
      try {
         waitingDAO = new WaitingDAO();
      } catch (Exception e) {
         e.printStackTrace();
      }         
   }
   
   public static WaitingManager getInstance() {
      return waitingMan;
   }
   
   public int create(Waiting waiting) throws SQLException {
      return waitingDAO.create(waiting);
   }
   public int remove(int tNum, int waitNum) throws SQLException {
      return waitingDAO.remove(tNum, waitNum);
   }
   public List<Waiting> findWaitingList(int tnum) throws SQLException {   
      return waitingDAO.findWaitingList(tnum);    
   }
   public List<Waiting> findWaitingMnumList(int mnum) throws SQLException {
	   return waitingDAO.findWaitingMnumList(mnum);
   }
   public int findLastWaitNum(int tnum) throws SQLException {
      return waitingDAO.findLastWaitNum(tnum);
   }
   public Waiting findWaitNum(int tnum, int mnum) throws SQLException {
	      return waitingDAO.findWaitNum(tnum, mnum);
   }
   public int removeWaiting(Waiting waiting) throws SQLException {
	   return waitingDAO.removeWaiting(waiting);
   }
   
   public WaitingDAO getWaitingDAO() {
      return this.waitingDAO;
   }
}